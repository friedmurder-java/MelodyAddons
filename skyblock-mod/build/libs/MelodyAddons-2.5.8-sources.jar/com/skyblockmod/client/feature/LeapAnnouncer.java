package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_310;

public class LeapAnnouncer {

    private static final Pattern LEAPED_PATTERN = Pattern.compile(
            "You have teleported to (\\w{1,16})!",
            Pattern.CASE_INSENSITIVE
    );

    private static final LeapAnnouncer INSTANCE = new LeapAnnouncer();
    public static LeapAnnouncer get() { return INSTANCE; }
    private LeapAnnouncer() {}

    public void onChatMessage(String raw) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.leapAnnounce) return;
        if (!ModConfig.nonEmpty(cfg.leapAnnounceMsg)) return;

        Matcher m = LEAPED_PATTERN.matcher(raw);
        if (!m.find()) return;

        String player = m.group(1);
        String msg = cfg.leapAnnounceMsg.replace("(player)", player);
        sendPc(msg);
    }

    private void sendPc(String message) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && mc.method_1562() != null)
            mc.method_1562().method_45730("pc " + message);
    }
}