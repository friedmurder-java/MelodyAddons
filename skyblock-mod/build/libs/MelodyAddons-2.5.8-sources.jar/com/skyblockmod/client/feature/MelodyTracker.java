package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_465;

public class MelodyTracker {

    private boolean inTerminal        = false;
    private boolean sentThreeQuarters = false;
    private int lastRow = -1;
    private List<String> selectedMessages = new ArrayList<>();

    private static final MelodyTracker INSTANCE = new MelodyTracker();
    public static MelodyTracker get() { return INSTANCE; }
    private MelodyTracker() {}

    public boolean isInTerminal() {
        if (inTerminal) return true;
        class_310 mc = class_310.method_1551();
        if (!(mc.field_1755 instanceof class_465<?> screen)) return false;
        return screen.method_25440().getString().toLowerCase().contains("click the button on time");
    }

    public void tick() {
        class_310 mc = class_310.method_1551();
        if (!(mc.field_1755 instanceof class_465<?> screen)) {
            if (inTerminal) onClose();
            return;
        }
        String title = screen.method_25440().getString();
        if (!title.toLowerCase().contains("click the button on time")) {
            if (inTerminal) onClose();
            return;
        }
        if (!inTerminal) {
            inTerminal = true;
            lastRow    = -1;
            selectMessages();
            onOpen();
        }
    }

    public void onSlotUpdate(String itemId, int slot) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.melodyMessages || !cfg.hasMelodyMessages()) return;

        class_310 mc = class_310.method_1551();
        if (!(mc.field_1755 instanceof class_465<?> screen)) return;
        String title = screen.method_25440().getString();
        if (!title.toLowerCase().contains("click the button on time")) return;

        if (itemId.equals("minecraft:lime_terracotta")) {
            int row = slot / 9;
            if (row == lastRow) return;
            lastRow = row;

            int index = row - 2;
            if (index >= 0 && index < selectedMessages.size()) {
                String msg = selectedMessages.get(index) + " " + (index + 1) + "/4";
                sendPc(msg);
                if (index == 2) sentThreeQuarters = true;
            }
        }
    }

    private void selectMessages() {
        ModConfig cfg = ModConfig.get();
        List<String> pool = new ArrayList<>(cfg.melodyMsgPool);
        Collections.shuffle(pool);
        selectedMessages = new ArrayList<>(pool.subList(0, Math.min(3, pool.size())));
    }

    private void onOpen() {
        ModConfig cfg = ModConfig.get();
        if (!cfg.melodyMessages) return;
        if (ModConfig.nonEmpty(cfg.melodyMsgStart)) sendPc(cfg.melodyMsgStart);
    }

    private void onClose() {
        if (sentThreeQuarters) {
            ModConfig cfg = ModConfig.get();
            if (cfg.melodyMessages && ModConfig.nonEmpty(cfg.melodyMsgClose))
                sendPc(cfg.melodyMsgClose);
        }
        inTerminal        = false;
        lastRow           = -1;
        sentThreeQuarters = false;
        selectedMessages.clear();
    }

    private void sendPc(String message) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && mc.method_1562() != null)
            mc.method_1562().method_45730("pc " + message);
    }
}