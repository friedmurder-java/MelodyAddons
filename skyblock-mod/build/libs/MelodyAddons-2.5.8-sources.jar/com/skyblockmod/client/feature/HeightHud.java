package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class HeightHud {

    private static final HeightHud INSTANCE = new HeightHud();
    public static HeightHud get() { return INSTANCE; }
    private HeightHud() {}

    public void render(class_332 ctx) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.heightHud) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1755 != null) return;

        HudElement el = cfg.getHudElement("height");
        class_327 tr = mc.field_1772;

        int y = (int) mc.field_1724.method_23318();
        String text = "Height: " + y;

        int textW = tr.method_1727(text);
        int textH = tr.field_2000;

        float scale = el.scale;
        int px = (int) el.x;
        int py = (int) el.y;

        int padX = 6;
        int padY = 4;
        int boxW = (int)((textW + padX * 2) * scale);
        int boxH = (int)((textH + padY * 2) * scale);

        // Background
        ctx.method_25294(px, py, px + boxW, py + boxH, 0x55000000);
        // Border hint
        ctx.method_25294(px, py, px + boxW, py + 1, 0x44FFFFFF);
        ctx.method_25294(px, py + boxH - 1, px + boxW, py + boxH, 0x44FFFFFF);
        ctx.method_25294(px, py, px + 1, py + boxH, 0x44FFFFFF);
        ctx.method_25294(px + boxW - 1, py, px + boxW, py + boxH, 0x44FFFFFF);

        // Text
        ctx.method_51448().pushMatrix();
        ctx.method_51448().translate(px + padX * scale, py + padY * scale);
        ctx.method_51448().scale(scale, scale);
        ctx.method_25303(tr, text, 0, 0, 0xFFFFFFFF);
        ctx.method_51448().popMatrix();
    }
}