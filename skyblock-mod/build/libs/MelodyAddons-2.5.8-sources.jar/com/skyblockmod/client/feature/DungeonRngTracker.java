package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public class DungeonRngTracker {

    private static final Pattern DROP_CHAT_FULL = Pattern.compile(
            "RARE DROP!\\s+(.+?)\\s+\\(([\\d,]+)\\s+RNG Meter\\)",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern DROP_CHAT_SHORT = Pattern.compile(
            "RNG METER\\s*-\\s*(.+)",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern LORE_PROGRESS = Pattern.compile(
            "([\\d,]+(?:\\.\\d+)?(?:[kKmM])?)\\s*/\\s*([\\d,]+(?:\\.\\d+)?(?:[kKmM])?)",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern TEAM_SCORE_CHAT = Pattern.compile(
            "Team Score:\\s*([\\d,]+)\\s*\\(S[+]?\\)",
            Pattern.CASE_INSENSITIVE
    );

    private long cachedXp;
    private long cachedMaxXp;
    private String cachedItem;

    private static final DungeonRngTracker INSTANCE = new DungeonRngTracker();
    public static DungeonRngTracker get() { return INSTANCE; }

    private DungeonRngTracker() {
        ModConfig cfg = ModConfig.get();
        cachedXp    = cfg.rngCachedXp;
        cachedMaxXp = cfg.rngCachedMaxXp;
        cachedItem  = cfg.rngCachedItem;
    }

    public long getCachedXp()    { return cachedXp; }
    public long getCachedMaxXp() { return cachedMaxXp; }

    private void saveToConfig() {
        ModConfig cfg = ModConfig.get();
        cfg.rngCachedXp    = cachedXp;
        cfg.rngCachedMaxXp = cachedMaxXp;
        cfg.rngCachedItem  = cachedItem != null ? cachedItem : "";
        cfg.save();
    }

    public void tick() {
        class_310 mc = class_310.method_1551();
        if (!(mc.field_1755 instanceof class_465<?> screen)) return;
        String title = screen.method_25440().getString();
        if (!title.toLowerCase().contains("catacombs rng meter")) return;

        class_1703 handler = screen.method_17577();

        // First pass: look for selected item
        for (int i = 0; i < handler.field_7761.size(); i++) {
            class_1799 stack = handler.field_7761.get(i).method_7677();
            if (stack.method_7960()) continue;

            class_9290 lore = stack.method_58694(class_9334.field_49632);
            if (lore == null) continue;

            boolean isSelected = false;
            long xp = -1, maxXp = -1;

            for (class_2561 line : lore.comp_2400()) {
                String plain = line.getString();
                if (plain.toLowerCase().contains("selected")) isSelected = true;
                Matcher m = LORE_PROGRESS.matcher(plain);
                if (m.find()) {
                    xp    = parseNumber(m.group(1));
                    maxXp = parseNumber(m.group(2));
                }
            }

            if (isSelected && xp >= 0) {
                cachedXp    = xp;
                cachedMaxXp = maxXp;
                cachedItem  = stack.method_7964().getString();
                saveToConfig();
                return;
            }
        }

        // Second pass: fallback to first valid item
        for (int i = 0; i < handler.field_7761.size(); i++) {
            class_1799 stack = handler.field_7761.get(i).method_7677();
            if (stack.method_7960()) continue;

            class_9290 lore = stack.method_58694(class_9334.field_49632);
            if (lore == null) continue;

            for (class_2561 line : lore.comp_2400()) {
                String plain = line.getString();
                Matcher m = LORE_PROGRESS.matcher(plain);
                if (m.find()) {
                    cachedXp    = parseNumber(m.group(1));
                    cachedMaxXp = parseNumber(m.group(2));
                    cachedItem  = stack.method_7964().getString();
                    saveToConfig();
                    return;
                }
            }
        }

        // Kein Item gefunden — Menü offen aber kein drop selected
        cachedXp    = 0;
        cachedMaxXp = 0;
        cachedItem  = null;
        saveToConfig();
    }

    public void onChatMessage(String raw) {
        if (!ModConfig.get().dungeonRngTracker) return;

        Matcher mScore = TEAM_SCORE_CHAT.matcher(raw);
        if (mScore.find() && cachedXp >= 0) {
            long score = parseNumber(mScore.group(1));
            double multiplier = ModConfig.get().dungeonRngBlessed ? 1.1 : 1.0;
            long gained = (long)(score * multiplier);
            cachedXp = cachedXp + gained;
            saveToConfig();
            sendClientMessage(String.format(
                    "§b[MelodyAddons] §7RNG Meter: §6%s §7/ §6%s §7(§a+%s XP§7)",
                    fmt(cachedXp), fmt(cachedMaxXp), fmt(gained)));
            return;
        }

        Matcher mFull  = DROP_CHAT_FULL.matcher(raw);
        Matcher mShort = DROP_CHAT_SHORT.matcher(raw);

        if (mFull.find())  { handleDrop(mFull.group(1).trim());  return; }
        if (mShort.find()) { handleDrop(mShort.group(1).trim()); }
    }

    private void handleDrop(String itemFromChat) {
        String itemName = (cachedItem != null && !cachedItem.isEmpty()) ? cachedItem : itemFromChat;

        StringBuilder msg = new StringBuilder();
        msg.append("§b[MelodyAddons] §e✦ §6").append(itemName).append(" §edropped! ");

        if (cachedXp >= 0 && cachedMaxXp > 0) {
            double pct = (cachedXp * 100.0) / cachedMaxXp;
            msg.append(String.format("§7You were at §a%.1f%%§7 — ", pct));
            msg.append("§6").append(fmt(cachedXp))
                    .append(" §7/ §6").append(fmt(cachedMaxXp))
                    .append(" §7XP.");
        }

        sendClientMessage(msg.toString());
        cachedXp = 0;
        cachedMaxXp = 0;
        cachedItem = null;
        saveToConfig();
    }

    private void sendClientMessage(String text) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470(text), false);
    }

    private static String fmt(long n) { return String.format("%,d", n); }

    private static long parseNumber(String s) {
        try {
            s = s.replace(",", "").trim();
            if (s.endsWith("M") || s.endsWith("m")) {
                return (long)(Double.parseDouble(s.substring(0, s.length()-1)) * 1_000_000);
            }
            if (s.endsWith("k") || s.endsWith("K")) {
                return (long)(Double.parseDouble(s.substring(0, s.length()-1)) * 1000);
            }
            if (s.contains(".")) {
                return (long) Double.parseDouble(s);
            }
            return Long.parseLong(s);
        } catch (NumberFormatException e) { return -1; }
    }
}