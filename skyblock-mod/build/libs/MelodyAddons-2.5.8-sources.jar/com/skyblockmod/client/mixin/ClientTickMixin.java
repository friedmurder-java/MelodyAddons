package com.skyblockmod.client.mixin;

import com.skyblockmod.client.config.ModConfig;
import com.skyblockmod.client.feature.ChatTriggerManager;
import com.skyblockmod.client.feature.CocoonAlert;
import com.skyblockmod.client.feature.DungeonRngTracker;
import com.skyblockmod.client.feature.MelodyTracker;
import com.skyblockmod.client.feature.SlayerRngTracker;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class ClientTickMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        com.skyblockmod.client.feature.BerserkerTracker.get().tick();
        SlayerRngTracker.get().tick();
        DungeonRngTracker.get().tick();
        CocoonAlert.get().tick();
        MelodyTracker.get().tick();
        ChatTriggerManager.get().tick();

        class_310 mc = class_310.method_1551();
        if (mc.field_1690 != null && ModConfig.get().fullbright) {
            mc.field_1690.method_42473().method_41748(Double.MAX_VALUE);
        }
    }
}