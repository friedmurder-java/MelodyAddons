package com.skyblockmod.client.mixin;

import com.skyblockmod.client.feature.ChatTriggerManager;
import com.skyblockmod.client.feature.CocoonAlert;
import com.skyblockmod.client.feature.HeightHud;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class HudRenderMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 ctx, class_9779 tickCounter, CallbackInfo ci) {
        CocoonAlert.get().render(ctx, ctx.method_51421(), ctx.method_51443());
        ChatTriggerManager.get().render(ctx, ctx.method_51421(), ctx.method_51443());
        HeightHud.get().render(ctx);
    }
}