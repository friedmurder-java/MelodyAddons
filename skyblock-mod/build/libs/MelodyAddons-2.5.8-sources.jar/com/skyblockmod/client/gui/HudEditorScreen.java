package com.skyblockmod.client.gui;

import com.skyblockmod.client.config.ModConfig;
import com.skyblockmod.client.feature.HeightHud;
import com.skyblockmod.client.feature.HudElement;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class HudEditorScreen extends class_437 {

    private HudElement dragging = null;
    private float dragOffsetX, dragOffsetY;

    public HudEditorScreen() {
        super(class_2561.method_43470("HUD Editor"));
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Dark overlay
        ctx.method_25294(0, 0, field_22789, field_22790, 0x88000000);

        // Render all HUD elements in editor mode
        HeightHud.get().render(ctx);

        // Render selection box around hovered/dragged element
        ModConfig cfg = ModConfig.get();
        HudElement el = cfg.getHudElement("height");
        if (cfg.heightHud) {
            renderSelectionBox(ctx, el, mouseX, mouseY);
        }

        // Instructions
        ctx.method_27534(field_22793,
                class_2561.method_43470("§7Drag to move  ·  Scroll to resize  ·  ESC to close"),
                field_22789 / 2, field_22790 - 20, 0xFFAAAAAA);

        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    private void renderSelectionBox(class_332 ctx, HudElement el, int mouseX, int mouseY) {
        int mc2 = net.minecraft.class_310.method_1551().field_1772.method_1727("Height: 64");
        int boxW = (int)((mc2 + 12) * el.scale);
        int boxH = (int)((9 + 8) * el.scale);

        int px = (int) el.x;
        int py = (int) el.y;

        boolean hovered = mouseX >= px && mouseX <= px + boxW && mouseY >= py && mouseY <= py + boxH;
        int color = (dragging == el || hovered) ? 0xFF4A90D9 : 0x664A90D9;

        ctx.method_25294(px - 1, py - 1, px + boxW + 1, py, color);
        ctx.method_25294(px - 1, py + boxH, px + boxW + 1, py + boxH + 1, color);
        ctx.method_25294(px - 1, py, px, py + boxH, color);
        ctx.method_25294(px + boxW, py, px + boxW + 1, py + boxH, color);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (click.method_74245() == 0) {
            ModConfig cfg = ModConfig.get();
            HudElement el = cfg.getHudElement("height");
            if (cfg.heightHud && isOverElement(el, (int) click.comp_4798(), (int) click.comp_4799())) {
                dragging = el;
                dragOffsetX = (float) click.comp_4798() - el.x;
                dragOffsetY = (float) click.comp_4799() - el.y;
                return true;
            }
        }
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (click.method_74245() == 0 && dragging != null) {
            dragging = null;
            ModConfig.get().save();
            return true;
        }
        return super.method_25406(click);
    }

    @Override
    public boolean method_25403(class_11909 click, double offsetX, double offsetY) {
        if (dragging != null) {
            dragging.x = (float) click.comp_4798() - dragOffsetX;
            dragging.y = (float) click.comp_4799() - dragOffsetY;
            // Clamp to screen
            dragging.x = Math.max(0, Math.min(field_22789 - 50, dragging.x));
            dragging.y = Math.max(0, Math.min(field_22790 - 20, dragging.y));
            return true;
        }
        return super.method_25403(click, offsetX, offsetY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        ModConfig cfg = ModConfig.get();
        HudElement el = cfg.getHudElement("height");
        if (cfg.heightHud && isOverElement(el, (int) mouseX, (int) mouseY)) {
            el.scale = Math.max(0.5f, Math.min(4.0f, el.scale + (float) verticalAmount * 0.1f));
            cfg.save();
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    private boolean isOverElement(HudElement el, int mx, int my) {
        int textW = net.minecraft.class_310.method_1551().field_1772.method_1727("Height: 64");
        int boxW = (int)((textW + 12) * el.scale);
        int boxH = (int)((9 + 8) * el.scale);
        return mx >= el.x && mx <= el.x + boxW && my >= el.y && my <= el.y + boxH;
    }

    @Override
    public boolean method_25421() { return false; }
}

