package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import java.util.regex.Pattern;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3417;

public class CocoonAlert {

    private static final Pattern COCOON_PATTERN = Pattern.compile(
            "cocooned? (your|the) (slayer )?boss",
            Pattern.CASE_INSENSITIVE
    );

    private static final int DISPLAY_TICKS = 60;
    private int ticksLeft = 0;

    private static final CocoonAlert INSTANCE = new CocoonAlert();
    public static CocoonAlert get() { return INSTANCE; }
    private CocoonAlert() {}

    public void tick() {
        if (ticksLeft > 0) ticksLeft--;
    }

    public void onChatMessage(String raw) {
        if (!ModConfig.get().cocoonAlert) return;
        if (COCOON_PATTERN.matcher(raw).find()) {
            ticksLeft = DISPLAY_TICKS;
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 != null) {
                mc.field_1724.method_5783(class_3417.field_14627, 1.0f, 1.0f);
            }
        }
    }

    public void render(class_332 ctx, int screenWidth, int screenHeight) {
        if (!ModConfig.get().cocoonAlert || ticksLeft <= 0) return;

        class_310 mc = class_310.method_1551();
        class_327 tr = mc.field_1772;
        if (tr == null) return;

        float alpha = ticksLeft < 20 ? (ticksLeft / 20.0f) : 1.0f;
        int a = (int)(alpha * 255) & 0xFF;
        int redA   = (a << 24) | (0xFF << 16) | 0x0000;
        int shadow = (a << 24) | 0x3F0000;

        String line1 = "COCOONED!";
        float scale = 5.0f;
        int textW = tr.method_1727(line1);

        float x = (screenWidth  - textW  * scale) / 2f;
        float y = (screenHeight - tr.field_2000 * scale) / 2f;

        ctx.method_51448().pushMatrix();
        ctx.method_51448().translate(x, y);
        ctx.method_51448().scale(scale, scale);
        ctx.method_51433(tr, line1, 1, 1, shadow, false);
        ctx.method_51433(tr, line1, 0, 0, redA, false);
        ctx.method_51448().popMatrix();
    }
}