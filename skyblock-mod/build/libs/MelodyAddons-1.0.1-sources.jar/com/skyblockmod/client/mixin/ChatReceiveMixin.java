package com.skyblockmod.client.mixin;

import com.skyblockmod.client.feature.ChatTriggerManager;
import com.skyblockmod.client.feature.CocoonAlert;
import com.skyblockmod.client.feature.DungeonRngTracker;
import com.skyblockmod.client.feature.SlayerRngTracker;
import net.minecraft.class_2561;
import net.minecraft.class_634;
import net.minecraft.class_7439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ChatReceiveMixin {

    @Inject(method = "onGameMessage", at = @At("TAIL"))
    private void onGameMessage(class_7439 packet, CallbackInfo ci) {
        class_2561 msg = packet.comp_763();
        if (msg == null) return;
        String plain = msg.getString();
        SlayerRngTracker.get().onChatMessage(plain);
        DungeonRngTracker.get().onChatMessage(plain);
        CocoonAlert.get().onChatMessage(plain);
        ChatTriggerManager.get().onChatMessage(plain);
    }
}