package com.skyblockmod.client.mixin;

import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;

// /oskar is now handled via Fabric client command API in SkyblockModClient
@Mixin(class_634.class)
public class ChatSendMixin {
}
