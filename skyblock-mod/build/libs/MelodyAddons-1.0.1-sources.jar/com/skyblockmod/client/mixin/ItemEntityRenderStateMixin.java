package com.skyblockmod.client.mixin;

import com.skyblockmod.client.config.ModConfig;
import com.skyblockmod.client.rarity.RarityResolver;
import com.skyblockmod.client.rarity.SkyblockRarity;
import net.minecraft.class_10039;
import net.minecraft.class_1542;
import net.minecraft.class_916;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_916.class)
public class ItemEntityRenderStateMixin {

    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void onUpdateRenderState(class_1542 entity, class_10039 state, float tickDelta, CallbackInfo ci) {
        if (!ModConfig.get().rarityGlow) return;

        SkyblockRarity rarity = RarityResolver.resolve(entity);
        if (rarity == null) return;

        // outlineColor is an int field on ItemEntityRenderState — set it to the rarity color
        state.field_61821 = rarity.color;
    }
}
