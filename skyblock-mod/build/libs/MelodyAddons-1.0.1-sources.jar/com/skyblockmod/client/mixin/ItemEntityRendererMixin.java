package com.skyblockmod.client.mixin;

import net.minecraft.class_916;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_916.class)
public class ItemEntityRendererMixin {
}
