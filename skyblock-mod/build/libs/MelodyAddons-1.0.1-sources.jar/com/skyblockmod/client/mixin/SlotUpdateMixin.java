package com.skyblockmod.client.mixin;

import com.skyblockmod.client.feature.MelodyTracker;
import net.minecraft.class_2653;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class SlotUpdateMixin {

    @Inject(method = "onScreenHandlerSlotUpdate", at = @At("HEAD"))
    private void onSlotUpdate(class_2653 packet, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        if (packet.method_11449().method_7960()) return;
        String itemId = packet.method_11449().method_7909().toString();
        int slot = packet.method_11450();
        MelodyTracker.get().onSlotUpdate(itemId, slot);
    }
}