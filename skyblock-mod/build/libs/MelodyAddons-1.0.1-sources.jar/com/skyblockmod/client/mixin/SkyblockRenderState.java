package com.skyblockmod.client.mixin;

import com.skyblockmod.client.rarity.SkyblockRarity;
import java.util.WeakHashMap;
import net.minecraft.class_10039;

/**
 * Stores per-render-state rarity data.
 *
 * We use a WeakHashMap so entries are automatically cleaned up when
 * render state objects are garbage collected.
 */
public class SkyblockRenderState {

    private static final WeakHashMap<class_10039, SkyblockRarity> RARITY_MAP = new WeakHashMap<>();

    public static void setRarity(class_10039 state, SkyblockRarity rarity) {
        if (rarity != null) {
            RARITY_MAP.put(state, rarity);
        } else {
            RARITY_MAP.remove(state);
        }
    }

    public static SkyblockRarity getRarity(class_10039 state) {
        return RARITY_MAP.get(state);
    }
}
