package com.skyblockmod.client.gui;

import com.skyblockmod.client.config.ModConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;

public class ModMenuScreen extends class_437 {

    private static final int BG_COLOR      = 0xCC0D0D0D;
    private static final int PANEL_COLOR   = 0xFF1A1A2E;
    private static final int ACCENT        = 0xFF4A90D9;
    private static final int TAB_COLOR     = 0xFF12122A;
    private static final int TAB_ACTIVE    = 0xFF1E1E3A;
    private static final int TEXT_COLOR    = 0xFFEEEEEE;
    private static final int SUBTEXT_COLOR = 0xFF888888;
    private static final int FIELD_BG      = 0xFF0A0A1A;
    private static final int FIELD_BORDER  = 0xFF334466;
    private static final int FIELD_ACTIVE  = 0xFF4A90D9;

    private static final int TAB_W     = 90;
    private static final int TAB_H     = 36;
    private static final int CONTENT_W = 380;
    private static final int TOGGLE_H  = 44;
    private static final int TEXT_H    = 58;
    private static final int POOL_H    = 30;
    private static final int SECTION_H = 32;
    private static final int TOGGLE_SW = 40;
    private static final int TOGGLE_SH = 20;
    private static final int PADDING   = 14;
    private static final int HEADER_H  = 46;
    private static final int FOOTER_H  = 20;

    private static final String[] TABS = {"Misc", "Melody"};

    private sealed interface Row permits ToggleRow, TextRow, PoolHeaderRow, PoolItemRow {}
    private record ToggleRow(String label, String description, Supplier<Boolean> getter, Consumer<Boolean> setter) implements Row {}
    private record TextRow(String label, String description, String placeholder, Supplier<String> getter, Consumer<String> setter) implements Row {}
    private record PoolHeaderRow() implements Row {}
    private record PoolItemRow(int index) implements Row {}

    private final List<Row> rows = new ArrayList<>();
    private final List<class_342> fields = new ArrayList<>();
    private final Map<String, Float> animStates = new HashMap<>();

    private int panelX, panelY, panelH, panelW;
    private int contentX;
    private int scrollOffset = 0;
    private int maxScroll = 0;
    private int activeTab = 0;
    private boolean poolExpanded = true;

    public ModMenuScreen() {
        super(class_2561.method_43470("MyMod"));
    }

    @Override
    protected void method_25426() {
        rows.clear();
        fields.forEach(this::method_37066);
        fields.clear();
        buildRows();

        panelW = TAB_W + CONTENT_W;
        int contentH = HEADER_H + FOOTER_H;
        for (Row r : rows) contentH += rowHeight(r);

        panelH = Math.min(contentH, field_22790 - 20);
        panelX = (field_22789 - panelW) / 2;
        panelY = (field_22790 - panelH) / 2;
        contentX = panelX + TAB_W;
        maxScroll = Math.max(0, contentH - panelH);
        scrollOffset = Math.min(scrollOffset, maxScroll);

        rebuildTextFields();
    }

    private int rowHeight(Row r) {
        if (r instanceof TextRow)       return TEXT_H;
        if (r instanceof PoolItemRow)   return POOL_H;
        if (r instanceof PoolHeaderRow) return SECTION_H;
        return TOGGLE_H;
    }

    private void buildRows() {
        ModConfig cfg = ModConfig.get();

        if (activeTab == 0) {
            addToggle("Rarity Glow", "Outline dropped items with rarity colour",
                    () -> cfg.rarityGlow, v -> { cfg.rarityGlow = v; cfg.save(); });
            addToggle("Slayer RNG Tracker", "Show XP reset + drop % on slayer drops",
                    () -> cfg.slayerRngTracker, v -> { cfg.slayerRngTracker = v; cfg.save(); });
            addToggle("Dungeon RNG Tracker", "Show drop % from tab on dungeon drops",
                    () -> cfg.dungeonRngTracker, v -> { cfg.dungeonRngTracker = v; cfg.save(); });
            addToggle("Cocoon Alert", "Big COCOONED! text when you cocoon a slayer boss",
                    () -> cfg.cocoonAlert, v -> { cfg.cocoonAlert = v; cfg.save(); });
        } else {
            addToggle("Enable Melody Messages", "Send /pc messages during the terminal",
                    () -> cfg.melodyMessages, v -> { cfg.melodyMessages = v; cfg.save(); });
            addTextField("Start Message", "Sent to /pc when you open the terminal",
                    "e.g. doing melody!", () -> cfg.melodyMsgStart, v -> { cfg.melodyMsgStart = v; cfg.save(); });
            addTextField("Close Message", "Sent to /pc when terminal finishes",
                    "e.g. melody done!", () -> cfg.melodyMsgClose, v -> { cfg.melodyMsgClose = v; cfg.save(); });
            rows.add(new PoolHeaderRow());
            if (poolExpanded) {
                for (int i = 0; i < cfg.melodyMsgPool.size(); i++) {
                    rows.add(new PoolItemRow(i));
                }
            }
        }
    }

    private void addToggle(String label, String desc, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        rows.add(new ToggleRow(label, desc, getter, setter));
    }

    private void addTextField(String label, String desc, String placeholder, Supplier<String> getter, Consumer<String> setter) {
        rows.add(new TextRow(label, desc, placeholder, getter, setter));
    }

    private void rebuildTextFields() {
        fields.forEach(this::method_37066);
        fields.clear();
        int y = panelY + HEADER_H;
        ModConfig cfg = ModConfig.get();

        for (Row row : rows) {
            if (row instanceof TextRow tr) {
                class_342 field = new class_342(
                        field_22793, contentX + PADDING + 2, y + TEXT_H - 24 - scrollOffset,
                        CONTENT_W - PADDING * 2 - 4, 16, class_2561.method_43470(tr.label()));
                field.method_1880(128);
                field.method_1852(tr.getter().get());
                field.method_47404(class_2561.method_43470("§8" + tr.placeholder()));
                field.method_1863(tr.setter()::accept);
                field.method_1858(true);
                method_37063(field);
                fields.add(field);
            } else if (row instanceof PoolItemRow pr) {
                String val = pr.index() < cfg.melodyMsgPool.size() ? cfg.melodyMsgPool.get(pr.index()) : "";
                class_342 field = new class_342(
                        field_22793, contentX + PADDING + 2, y + POOL_H - 20 - scrollOffset,
                        CONTENT_W - PADDING * 2 - 32, 16, class_2561.method_43470("msg" + pr.index()));
                field.method_1880(128);
                field.method_1852(val);
                field.method_47404(class_2561.method_43470("§8Enter message..."));
                int idx = pr.index();
                field.method_1863(text -> {
                    while (cfg.melodyMsgPool.size() <= idx) cfg.melodyMsgPool.add("");
                    cfg.melodyMsgPool.set(idx, text);
                    cfg.save();
                });
                field.method_1858(true);
                method_37063(field);
                fields.add(field);
            }
            y += rowHeight(row);
        }
    }

    // ── Animation helpers ─────────────────────────────────────────────────────

    private float getAnim(String key, boolean target) {
        float current = animStates.getOrDefault(key, target ? 1f : 0f);
        float speed = 0.12f;
        float next = target ? Math.min(1f, current + speed) : Math.max(0f, current - speed);
        animStates.put(key, next);
        return next;
    }

    private static int lerpColor(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int r  = (int)(ar + (br - ar) * t);
        int g  = (int)(ag + (bg - ag) * t);
        int bl = (int)(ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private static int lerpAlpha(int color, float alpha) {
        int a = (int)(alpha * 255) & 0xFF;
        return (color & 0x00FFFFFF) | (a << 24);
    }

    // ── Rendering ─────────────────────────────────────────────────────────────

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        ctx.method_25294(0, 0, field_22789, field_22790, BG_COLOR);
        ctx.method_25294(panelX, panelY, panelX + TAB_W, panelY + panelH, 0xFF0F0F20);
        ctx.method_25294(contentX, panelY, contentX + CONTENT_W, panelY + panelH, PANEL_COLOR);
        ctx.method_25294(panelX, panelY, panelX + panelW, panelY + 3, ACCENT);

        for (int i = 0; i < TABS.length; i++) {
            renderTab(ctx, i, mouseX, mouseY);
        }

        ctx.method_25294(contentX, panelY + 3, contentX + 1, panelY + panelH, 0xFF333355);

        ctx.method_44379(contentX, panelY + 3, contentX + CONTENT_W, panelY + panelH - FOOTER_H);
        renderContentHeader(ctx);

        int y = panelY + HEADER_H;
        int fi = 0;

        for (Row row : rows) {
            int rowH = rowHeight(row);
            int sy = y - scrollOffset;

            if (sy + rowH > panelY + 3 && sy < panelY + panelH - FOOTER_H) {
                if (row instanceof ToggleRow tr) {
                    renderToggleRow(ctx, tr, sy, mouseX, mouseY);
                } else if (row instanceof TextRow tr) {
                    renderTextRow(ctx, tr, sy, fi, mouseX, mouseY);
                    if (fi < fields.size()) {
                        class_342 fw = fields.get(fi);
                        fw.method_46421(contentX + PADDING + 2);
                        fw.method_46419(sy + rowH - 22);
                        fw.field_22764 = fw.method_46427() > panelY + HEADER_H && fw.method_46427() + 16 < panelY + panelH - FOOTER_H;
                    }
                    fi++;
                } else if (row instanceof PoolHeaderRow) {
                    renderPoolHeader(ctx, sy, mouseX, mouseY);
                } else if (row instanceof PoolItemRow pr) {
                    renderPoolItem(ctx, pr, sy, fi, mouseX, mouseY);
                    if (fi < fields.size()) {
                        class_342 fw = fields.get(fi);
                        fw.method_46421(contentX + PADDING + 2);
                        fw.method_46419(sy + rowH - 22);
                        fw.field_22764 = fw.method_46427() > panelY + HEADER_H && fw.method_46427() + 16 < panelY + panelH - FOOTER_H;
                    }
                    fi++;
                }
            } else if (row instanceof TextRow || row instanceof PoolItemRow) {
                if (fi < fields.size()) fields.get(fi).field_22764 = false;
                fi++;
            }
            y += rowH;
        }

        ctx.method_44380();

        ctx.method_27534(field_22793, class_2561.method_43470("§8ESC to close"),
                contentX + CONTENT_W / 2, panelY + panelH - 12, SUBTEXT_COLOR);
        if (maxScroll > 0) renderScrollbar(ctx);

        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    private void renderTab(class_332 ctx, int index, int mouseX, int mouseY) {
        int ty = panelY + HEADER_H + index * (TAB_H + 4);
        boolean active  = index == activeTab;
        boolean hovered = mouseX >= panelX && mouseX <= panelX + TAB_W
                && mouseY >= ty && mouseY < ty + TAB_H;

        float t  = getAnim("tab_" + index, active || hovered);
        float at = getAnim("tab_accent_" + index, active);

        int bg = lerpColor(TAB_COLOR, active ? TAB_ACTIVE : 0xFF16162E, t);
        ctx.method_25294(panelX, ty, panelX + TAB_W, ty + TAB_H, bg);

        // Animated accent bar
        int accentW = (int)(at * 3);
        if (accentW > 0)
            ctx.method_25294(panelX + TAB_W - accentW, ty, panelX + TAB_W, ty + TAB_H, ACCENT);

        int textColor = lerpColor(SUBTEXT_COLOR, TEXT_COLOR, t);
        ctx.method_27534(field_22793, class_2561.method_43470(TABS[index]),
                panelX + TAB_W / 2, ty + (TAB_H - 9) / 2, textColor);
    }

    private void renderContentHeader(class_332 ctx) {
        int hy = panelY + 8;
        ctx.method_27534(field_22793, class_2561.method_43470("§bMyMod §7— " + TABS[activeTab]),
                contentX + CONTENT_W / 2, hy, TEXT_COLOR);
        ctx.method_25294(contentX + PADDING, hy + 20, contentX + CONTENT_W - PADDING, hy + 21, 0xFF333355);
    }

    private void renderToggleRow(class_332 ctx, ToggleRow row, int y, int mouseX, int mouseY) {
        boolean hovered = mouseX >= contentX + PADDING && mouseX <= contentX + CONTENT_W - PADDING
                && mouseY >= y && mouseY < y + TOGGLE_H;

        float ht = getAnim("toggle_hover_" + row.label(), hovered);
        if (ht > 0) ctx.method_25294(contentX + PADDING, y, contentX + CONTENT_W - PADDING, y + TOGGLE_H,
                lerpAlpha(0xFFFFFF, ht * 0.07f));

        ctx.method_27535(field_22793, class_2561.method_43470(row.label()),
                contentX + PADDING + 4, y + 8, TEXT_COLOR);
        ctx.method_27535(field_22793, class_2561.method_43470("§8" + row.description()),
                contentX + PADDING + 4, y + 20, SUBTEXT_COLOR);

        int sx = contentX + CONTENT_W - PADDING - TOGGLE_SW - 4;
        int sy = y + (TOGGLE_H - TOGGLE_SH) / 2;
        renderSwitch(ctx, sx, sy, row.getter().get(), row.label());
    }

    private void renderTextRow(class_332 ctx, TextRow row, int y, int fi, int mouseX, int mouseY) {
        ctx.method_27535(field_22793, class_2561.method_43470(row.label()),
                contentX + PADDING + 4, y + 6, TEXT_COLOR);
        ctx.method_27535(field_22793, class_2561.method_43470("§8" + row.description()),
                contentX + PADDING + 4, y + 18, SUBTEXT_COLOR);
        int fx = contentX + PADDING + 2, fy = y + TEXT_H - 22, fw = CONTENT_W - PADDING * 2 - 4;
        boolean active = fi < fields.size() && fields.get(fi).method_25370();
        ctx.method_25294(fx, fy, fx + fw, fy + 18, active ? FIELD_ACTIVE : FIELD_BORDER);
        ctx.method_25294(fx + 1, fy + 1, fx + fw - 1, fy + 17, FIELD_BG);
    }

    private void renderPoolHeader(class_332 ctx, int y, int mouseX, int mouseY) {
        boolean hovered = mouseX >= contentX + PADDING && mouseX < contentX + CONTENT_W - PADDING - 26
                && mouseY >= y && mouseY < y + SECTION_H;
        float ht = getAnim("pool_header_hover", hovered);
        if (ht > 0) ctx.method_25294(contentX + PADDING, y, contentX + CONTENT_W - PADDING, y + SECTION_H,
                lerpAlpha(0xFFFFFF, ht * 0.07f));

        String arrow = poolExpanded ? "▼" : "▶";
        int arrowX = contentX + CONTENT_W - PADDING - 30 - field_22793.method_1727(arrow);
        ctx.method_27535(field_22793, class_2561.method_43470("§7Message Pool"),
                contentX + PADDING + 4, y + (SECTION_H - 9) / 2, SUBTEXT_COLOR);
        ctx.method_27535(field_22793, class_2561.method_43470("§7" + arrow),
                arrowX, y + (SECTION_H - 9) / 2, SUBTEXT_COLOR);

        int bx = contentX + CONTENT_W - PADDING - 24;
        int by = y + (SECTION_H - 18) / 2;
        boolean btnH = mouseX >= bx && mouseX <= bx + 24 && mouseY >= by && mouseY <= by + 18;
        float bt = getAnim("pool_add_btn", btnH);
        ctx.method_25294(bx, by, bx + 24, by + 18, lerpColor(0xFF3A8A3A, 0xFF5AAA5A, bt));
        ctx.method_25294(bx + 1, by + 1, bx + 23, by + 17, lerpColor(0xFF2A6A2A, 0xFF4A9A4A, bt));
        ctx.method_27534(field_22793, class_2561.method_43470("§f+"), bx + 12, by + 5, TEXT_COLOR);
    }

    private void renderPoolItem(class_332 ctx, PoolItemRow row, int y, int fi, int mouseX, int mouseY) {
        int bx = contentX + CONTENT_W - PADDING - 24;
        int by = y + (POOL_H - 18) / 2;
        boolean hovered = mouseX >= bx && mouseX <= bx + 24 && mouseY >= by && mouseY <= by + 18;
        float bt = getAnim("pool_del_" + row.index(), hovered);
        ctx.method_25294(bx, by, bx + 24, by + 18, lerpColor(0xFF7A1A1A, 0xFFAA2A2A, bt));
        ctx.method_25294(bx + 1, by + 1, bx + 23, by + 17, lerpColor(0xFF8A2A2A, 0xFFBB3A3A, bt));
        ctx.method_27534(field_22793, class_2561.method_43470("§f✕"), bx + 12, by + 5, TEXT_COLOR);

        int fx = contentX + PADDING + 2, fy = y + POOL_H - 22, fw = CONTENT_W - PADDING * 2 - 32;
        boolean active = fi < fields.size() && fields.get(fi).method_25370();
        ctx.method_25294(fx, fy, fx + fw, fy + 18, active ? FIELD_ACTIVE : FIELD_BORDER);
        ctx.method_25294(fx + 1, fy + 1, fx + fw - 1, fy + 17, FIELD_BG);
    }

    private void renderSwitch(class_332 ctx, int x, int y, boolean on, String key) {
        float t = getAnim("sw_" + key, on);
        int track = lerpColor(0xFF363650, ACCENT, t);
        ctx.method_25294(x, y, x + TOGGLE_SW, y + TOGGLE_SH, track);
        ctx.method_25294(x + 1, y - 1, x + TOGGLE_SW - 1, y, track);
        ctx.method_25294(x + 1, y + TOGGLE_SH, x + TOGGLE_SW - 1, y + TOGGLE_SH + 1, track);
        int kx = (int)(x + 2 + t * (TOGGLE_SW - TOGGLE_SH));
        ctx.method_25294(kx, y + 2, kx + TOGGLE_SH - 4, y + TOGGLE_SH - 2, 0xFFFFFFFF);
        ctx.method_25294(kx + 1, y + 2, kx + TOGGLE_SH - 5, y + 4, 0x33FFFFFF);
    }

    private void renderScrollbar(class_332 ctx) {
        int totalH = panelH - FOOTER_H - HEADER_H;
        int barH = Math.max(20, totalH * totalH / (totalH + maxScroll));
        int barY = panelY + HEADER_H + (totalH - barH) * scrollOffset / maxScroll;
        int barX = contentX + CONTENT_W - 4;
        ctx.method_25294(barX, panelY + HEADER_H, barX + 3, panelY + panelH - FOOTER_H, 0xFF222233);
        ctx.method_25294(barX, barY, barX + 3, barY + barH, ACCENT);
    }

    // ── Input ─────────────────────────────────────────────────────────────────

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (click.method_74245() == 0) {
            for (int i = 0; i < TABS.length; i++) {
                int ty = panelY + HEADER_H + i * (TAB_H + 4);
                if ((int) click.comp_4798() >= panelX && (int) click.comp_4798() <= panelX + TAB_W
                        && (int) click.comp_4799() >= ty && (int) click.comp_4799() < ty + TAB_H) {
                    if (activeTab != i) {
                        activeTab = i;
                        scrollOffset = 0;
                        method_25426();
                    }
                    return true;
                }
            }

            int y = panelY + HEADER_H;
            ModConfig cfg = ModConfig.get();

            for (Row row : rows) {
                int rowH = rowHeight(row);
                int sy = y - scrollOffset;

                if (row instanceof ToggleRow tr) {
                    if ((int) click.comp_4798() >= contentX + PADDING && (int) click.comp_4798() <= contentX + CONTENT_W - PADDING
                            && (int) click.comp_4799() >= sy && (int) click.comp_4799() < sy + rowH) {
                        tr.setter().accept(!tr.getter().get());
                        return true;
                    }
                } else if (row instanceof PoolHeaderRow) {
                    int bx = contentX + CONTENT_W - PADDING - 24;
                    int arrowMaxX = bx - 4;
                    if ((int) click.comp_4798() >= contentX + PADDING && (int) click.comp_4798() < arrowMaxX
                            && (int) click.comp_4799() >= sy && (int) click.comp_4799() < sy + rowH) {
                        poolExpanded = !poolExpanded;
                        method_25426();
                        return true;
                    }
                    int by = sy + (SECTION_H - 18) / 2;
                    if ((int) click.comp_4798() >= bx && (int) click.comp_4798() <= bx + 24
                            && (int) click.comp_4799() >= by && (int) click.comp_4799() <= by + 18) {
                        cfg.melodyMsgPool.add("");
                        cfg.save();
                        method_25426();
                        return true;
                    }
                } else if (row instanceof PoolItemRow pr) {
                    int bx = contentX + CONTENT_W - PADDING - 24;
                    int by = sy + (POOL_H - 18) / 2;
                    if ((int) click.comp_4798() >= bx && (int) click.comp_4798() <= bx + 24
                            && (int) click.comp_4799() >= by && (int) click.comp_4799() <= by + 18) {
                        if (pr.index() < cfg.melodyMsgPool.size()) {
                            cfg.melodyMsgPool.remove(pr.index());
                            cfg.save();
                            method_25426();
                            return true;
                        }
                    }
                }
                y += rowH;
            }
        }
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollOffset = (int) Math.max(0, Math.min(maxScroll, scrollOffset - verticalAmount * 12));
        rebuildTextFields();
        return true;
    }

    @Override
    public boolean method_25421() { return false; }
}