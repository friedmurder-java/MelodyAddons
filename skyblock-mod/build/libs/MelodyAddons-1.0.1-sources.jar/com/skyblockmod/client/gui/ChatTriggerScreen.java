package com.skyblockmod.client.gui;

import com.skyblockmod.client.config.ModConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;

public class ChatTriggerScreen extends class_437 {

    private static final int BG_COLOR    = 0xCC0D0D0D;
    private static final int PANEL_COLOR = 0xFF1A1A2E;
    private static final int ACCENT      = 0xFF4A90D9;
    private static final int TEXT_COLOR  = 0xFFEEEEEE;
    private static final int SUBTEXT     = 0xFF888888;
    private static final int FIELD_BG    = 0xFF0A0A1A;
    private static final int FIELD_ON    = 0xFF4A90D9;
    private static final int FIELD_OFF   = 0xFF334466;

    private static final int PANEL_W  = 480;
    private static final int ROW_H    = 70;
    private static final int HEADER_H = 50;
    private static final int FOOTER_H = 20;
    private static final int PADDING  = 16;

    private int panelX, panelY, panelH;
    private int scrollOffset = 0;
    private int maxScroll    = 0;

    private final List<class_342> triggerFields = new ArrayList<>();
    private final List<class_342> outputFields  = new ArrayList<>();
    private final List<class_342> tickFields    = new ArrayList<>();

    public ChatTriggerScreen() {
        super(class_2561.method_43470("Chat Triggers"));
    }

    @Override
    protected void method_25426() {
        triggerFields.forEach(this::method_37066);
        outputFields.forEach(this::method_37066);
        tickFields.forEach(this::method_37066);
        triggerFields.clear();
        outputFields.clear();
        tickFields.clear();

        ModConfig cfg = ModConfig.get();
        int count = cfg.chatTriggers.size();
        int contentH = HEADER_H + FOOTER_H + count * ROW_H;

        panelH = Math.min(contentH, field_22790 - 20);
        panelX = (field_22789 - PANEL_W) / 2;
        panelY = (field_22790 - panelH) / 2;
        maxScroll = Math.max(0, contentH - panelH);
        scrollOffset = Math.min(scrollOffset, maxScroll);

        rebuildFields();
    }

    private void rebuildFields() {
        triggerFields.forEach(this::method_37066);
        outputFields.forEach(this::method_37066);
        tickFields.forEach(this::method_37066);
        triggerFields.clear();
        outputFields.clear();
        tickFields.clear();

        ModConfig cfg = ModConfig.get();
        int y = panelY + HEADER_H;

        for (int i = 0; i < cfg.chatTriggers.size(); i++) {
            ModConfig.ChatTrigger t = cfg.chatTriggers.get(i);
            int iy = y - scrollOffset;

            // Trigger field
            class_342 tf = new class_342(field_22793,
                    panelX + PADDING, iy + 8, 160, 16, class_2561.method_43470("trigger"));
            tf.method_1880(64);
            tf.method_1852(t.trigger);
            tf.method_47404(class_2561.method_43470("§8Trigger word..."));
            tf.method_1858(true);
            int idx = i;
            tf.method_1863(v -> { cfg.chatTriggers.get(idx).trigger = v; cfg.save(); });
            method_37063(tf);
            triggerFields.add(tf);

            // Output field
            class_342 of = new class_342(field_22793,
                    panelX + PADDING + 170, iy + 8, 190, 16, class_2561.method_43470("output"));
            of.method_1880(64);
            of.method_1852(t.output);
            of.method_47404(class_2561.method_43470("§8Display text..."));
            of.method_1858(true);
            of.method_1863(v -> { cfg.chatTriggers.get(idx).output = v; cfg.save(); });
            method_37063(of);
            outputFields.add(of);

            // Ticks field
            class_342 tkf = new class_342(field_22793,
                    panelX + PADDING + 370, iy + 8, 50, 16, class_2561.method_43470("ticks"));
            tkf.method_1880(5);
            tkf.method_1852(String.valueOf(t.ticks));
            tkf.method_47404(class_2561.method_43470("§860"));
            tkf.method_1858(true);
            tkf.method_1863(v -> {
                try { cfg.chatTriggers.get(idx).ticks = Integer.parseInt(v); cfg.save(); }
                catch (NumberFormatException ignored) {}
            });
            method_37063(tkf);
            tickFields.add(tkf);

            y += ROW_H;
        }
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        ctx.method_25294(0, 0, field_22789, field_22790, BG_COLOR);
        ctx.method_25294(panelX, panelY, panelX + PANEL_W, panelY + panelH, PANEL_COLOR);
        ctx.method_25294(panelX, panelY, panelX + PANEL_W, panelY + 3, ACCENT);

        ctx.method_44379(panelX, panelY + 3, panelX + PANEL_W, panelY + panelH - FOOTER_H);

        // Header
        int hy = panelY + 8;
        ctx.method_27534(field_22793, class_2561.method_43470("§bChat Triggers"),
                panelX + PANEL_W / 2, hy, TEXT_COLOR);
        ctx.method_27534(field_22793,
                class_2561.method_43470("§8Trigger | Output text | Ticks (duration)"),
                panelX + PANEL_W / 2, hy + 14, SUBTEXT);
        ctx.method_25294(panelX + PADDING, hy + 28, panelX + PANEL_W - PADDING, hy + 29, 0xFF333355);

        // Column headers
        int chy = panelY + HEADER_H - 14;
        ctx.method_27535(field_22793, class_2561.method_43470("§7Trigger"), panelX + PADDING, chy, SUBTEXT);
        ctx.method_27535(field_22793, class_2561.method_43470("§7Output"), panelX + PADDING + 170, chy, SUBTEXT);
        ctx.method_27535(field_22793, class_2561.method_43470("§7Ticks"), panelX + PADDING + 370, chy, SUBTEXT);

        // Rows
        ModConfig cfg = ModConfig.get();
        int y = panelY + HEADER_H;
        for (int i = 0; i < cfg.chatTriggers.size(); i++) {
            int sy = y - scrollOffset;
            if (sy + ROW_H > panelY + 3 && sy < panelY + panelH - FOOTER_H) {
                // Row background
                if (i % 2 == 0) ctx.method_25294(panelX + PADDING, sy, panelX + PANEL_W - PADDING, sy + ROW_H - 2, 0x08FFFFFF);

                // Reposition fields
                if (i < triggerFields.size()) {
                    triggerFields.get(i).method_46419(sy + 8);
                    triggerFields.get(i).field_22764 = true;
                }
                if (i < outputFields.size()) {
                    outputFields.get(i).method_46419(sy + 8);
                    outputFields.get(i).field_22764 = true;
                }
                if (i < tickFields.size()) {
                    tickFields.get(i).method_46419(sy + 8);
                    tickFields.get(i).field_22764 = true;
                }

                // X button
                int bx = panelX + PANEL_W - PADDING - 18;
                int by = sy + (ROW_H - 16) / 2;
                boolean hov = mouseX >= bx && mouseX <= bx + 16 && mouseY >= by && mouseY <= by + 16;
                ctx.method_25294(bx, by, bx + 16, by + 16, hov ? 0xFFAA3A3A : 0xFF7A2A2A);
                ctx.method_27534(field_22793, class_2561.method_43470("§fx"), bx + 8, by + 4, TEXT_COLOR);

                // Ticks label
                ctx.method_27535(field_22793, class_2561.method_43470("§8ticks"),
                        panelX + PADDING + 370, sy + 28, SUBTEXT);
            } else {
                if (i < triggerFields.size()) triggerFields.get(i).field_22764 = false;
                if (i < outputFields.size())  outputFields.get(i).field_22764  = false;
                if (i < tickFields.size())    tickFields.get(i).field_22764    = false;
            }
            y += ROW_H;
        }

        ctx.method_44380();

        // Footer
        ctx.method_27534(field_22793, class_2561.method_43470("§8Scroll  ·  ESC to close"),
                panelX + PANEL_W / 2, panelY + panelH - 12, SUBTEXT);

        // + Add button
        int addX = panelX + PANEL_W / 2 - 30;
        int addY = panelY + panelH - 16;
        ctx.method_25294(addX, addY, addX + 60, addY + 12, 0xFF3A7A3A);
        ctx.method_27534(field_22793, class_2561.method_43470("§f+ Add"), addX + 30, addY + 2, TEXT_COLOR);

        if (maxScroll > 0) renderScrollbar(ctx);

        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    private void renderScrollbar(class_332 ctx) {
        int totalH = panelH - FOOTER_H - HEADER_H;
        int barH = Math.max(20, totalH * totalH / (totalH + maxScroll));
        int barY = panelY + HEADER_H + (totalH - barH) * scrollOffset / maxScroll;
        int barX = panelX + PANEL_W - 4;
        ctx.method_25294(barX, panelY + HEADER_H, barX + 3, panelY + panelH - FOOTER_H, 0xFF222233);
        ctx.method_25294(barX, barY, barX + 3, barY + barH, 0xFF4A90D9);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        ModConfig cfg = ModConfig.get();
        int y = panelY + HEADER_H;

        // X buttons
        for (int i = 0; i < cfg.chatTriggers.size(); i++) {
            int sy = y - scrollOffset;
            int bx = panelX + PANEL_W - PADDING - 18;
            int by = sy + (ROW_H - 16) / 2;
            if ((int) click.comp_4798() >= bx && (int) click.comp_4798() <= bx + 16
                    && (int) click.comp_4799() >= by && (int) click.comp_4799() <= by + 16) {
                cfg.chatTriggers.remove(i);
                cfg.save();
                method_25426();
                return true;
            }
            y += ROW_H;
        }

        // + Add button
        int addX = panelX + PANEL_W / 2 - 30;
        int addY = panelY + panelH - 16;
        if ((int) click.comp_4798() >= addX && (int) click.comp_4798() <= addX + 60
                && (int) click.comp_4799() >= addY && (int) click.comp_4799() <= addY + 12) {
            cfg.chatTriggers.add(new ModConfig.ChatTrigger("", "", 60));
            cfg.save();
            method_25426();
            return true;
        }

        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollOffset = (int) Math.max(0, Math.min(maxScroll, scrollOffset - verticalAmount * 12));
        rebuildFields();
        return true;
    }

    @Override
    public boolean method_25421() { return false; }
}