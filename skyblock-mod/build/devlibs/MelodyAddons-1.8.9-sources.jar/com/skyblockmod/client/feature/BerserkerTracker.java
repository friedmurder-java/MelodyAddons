package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.*;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    private static final Pattern DEVICE_DONE = Pattern.compile("(.+) completed a device! \\(\\d+/7\\)", Pattern.CASE_INSENSITIVE);
    private static final Pattern SEVEN_OF_SEVEN = Pattern.compile("\\(7/7\\)");
    private static final String P3_START = "Who dares trespass into my domain";
    private static final String TIMER_TRIGGER = "Starting in 1 second.";

    private boolean inP3 = false, inS1 = false, berserkerDone = false, notDoneSent = false, doneMsgSent = false;
    private int sevenOfSevenCount = 0, scanDelayTicks = -1;

    private final List<String> berserkerNames = new ArrayList<>();
    private String lastActiveBerserker = null;

    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    public void tick() {
        if (scanDelayTicks > 0) scanDelayTicks--;
        else if (scanDelayTicks == 0) {
            performFullScan();
            scanDelayTicks = -1;
        }
    }

    public void onChatMessage(String raw) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.berserkerTracker) return;

        if (raw.contains(TIMER_TRIGGER)) {
            scanDelayTicks = 40;
            return;
        }

        if (raw.contains(P3_START)) {
            inP3 = true; inS1 = true; berserkerDone = false; notDoneSent = false; doneMsgSent = false;
            sevenOfSevenCount = 0; lastActiveBerserker = null;
            return;
        }

        if (!inP3) return;

        Matcher mDevice = DEVICE_DONE.matcher(raw);
        if (mDevice.find()) {
            String playerName = mDevice.group(1).trim();
            if (isKnownBerserker(playerName) || (berserkerNames.isEmpty() && isPlayerSelf(playerName))) {
                berserkerDone = true;
                lastActiveBerserker = playerName;
                if (!doneMsgSent && ModConfig.nonEmpty(cfg.berserkerMsgStart)) {
                    sendFormattedPc(cfg.berserkerMsgStart, playerName);
                    doneMsgSent = true;
                }
            }
        }

        if (SEVEN_OF_SEVEN.matcher(raw).find()) {
            sevenOfSevenCount++;
            if (sevenOfSevenCount == 1) {
                inS1 = false;
                if (!berserkerDone && !notDoneSent && ModConfig.nonEmpty(cfg.berserkerMsgNotDone)) {
                    sendFormattedPc(cfg.berserkerMsgNotDone, getBestBerserkerName());
                    notDoneSent = true;
                }
            } else if (sevenOfSevenCount == 2) {
                if (!berserkerDone && ModConfig.nonEmpty(cfg.berserkerMsgS4)) {
                    sendFormattedPc(cfg.berserkerMsgS4, getBestBerserkerName());
                }
                inP3 = false;
            }
        }
    }

    private void performFullScan() {
        berserkerNames.clear();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;

        Scoreboard scoreboard = mc.world.getScoreboard();
        ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);

        // Scan EVERY score on the sidebar
        if (objective != null) {
            for (ScoreboardEntry entry : scoreboard.getScoreboardEntries(objective)) {
                String rawLine = entry.name().getString();
                String owner = entry.owner();

                // If the line contains [B], try to find the player name on that line
                if (rawLine.contains("[B]") || owner.contains("[B]")) {
                    String merged = (rawLine + " " + owner).replaceAll("§[0-9a-fk-orx]", "");
                    findNamesInString(merged);
                }
            }
        }

        // Final fallback: Tab list search for [B]
        if (berserkerNames.isEmpty() && mc.getNetworkHandler() != null) {
            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
                Text dn = entry.getDisplayName();
                if (dn != null && dn.getString().contains("[B]")) {
                    String name = entry.getProfile().name();
                    if (!berserkerNames.contains(name)) berserkerNames.add(name);
                }
            }
        }

        if (mc.player != null) {
            String result = berserkerNames.isEmpty() ? "§7None" : "§b" + String.join(", ", berserkerNames);
            mc.player.sendMessage(Text.literal("§d[MelodyAddons] §fLocked Berserker(s): " + result), false);
        }
    }

    private void findNamesInString(String input) {
        // Hypixel names are 3-16 chars, alphanumeric or underscore
        Pattern p = Pattern.compile("[a-zA-Z0-9_]{3,16}");
        Matcher m = p.matcher(input.replace("[B]", ""));
        while (m.find()) {
            String potential = m.group();
            // Ignore common scoreboard words
            if (potential.equalsIgnoreCase("Health") || potential.equalsIgnoreCase("Dungeon")) continue;
            if (!berserkerNames.contains(potential)) berserkerNames.add(potential);
        }
    }

    private boolean isKnownBerserker(String playerName) {
        for (String name : berserkerNames) if (name.equalsIgnoreCase(playerName)) return true;
        return false;
    }

    private boolean isPlayerSelf(String playerName) {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player != null && mc.player.getName().getString().equalsIgnoreCase(playerName);
    }

    private String getBestBerserkerName() {
        if (lastActiveBerserker != null) return lastActiveBerserker;
        return !berserkerNames.isEmpty() ? berserkerNames.get(0) : "Berserker";
    }

    private void sendFormattedPc(String message, String name) {
        String finalMsg = message.replace("(berserker)", name);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.getNetworkHandler() != null)
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
    }
}
