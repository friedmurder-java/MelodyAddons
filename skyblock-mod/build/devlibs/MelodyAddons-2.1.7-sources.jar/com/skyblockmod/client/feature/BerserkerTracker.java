package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    // =========================
    // STATE
    // =========================
    private enum State {
        IDLE,
        WAITING_START,
        IN_DUNGEON,
        ACTIVE,
        CLEANUP
    }

    private State state = State.IDLE;

    // =========================
    // START CONTROL
    // =========================
    private boolean section1Active = false;
    private boolean startAnnounced = false;

    // =========================
    // BUFFER (VERY SHORT WINDOW)
    // =========================
    private int startGraceTicks = 0; // allows first device to arrive before printing

    // =========================
    // PATTERNS
    // =========================
    private static final String SCAN_TRIGGER = "Starting in 1 second.";
    private static final String P3_START = "Who dares trespass into my domain";

    private static final Pattern DEVICE_DONE =
            Pattern.compile("([A-Za-z0-9_]{3,16}).*completed a device! \\(\\d+/7\\)", Pattern.CASE_INSENSITIVE);

    private static final Pattern SEVEN_OF_SEVEN =
            Pattern.compile("\\(7/7\\)");

    // =========================
    // DATA
    // =========================
    private final List<String> berserkerList = new ArrayList<>();
    private String currentBerserker = null;

    private boolean berserkerDone = false;
    private boolean notDoneSent = false;
    private boolean s4Sent = false;

    private int sevenCount = 0;

    // =========================
    // SINGLETON
    // =========================
    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    // =========================
    // CHAT
    // =========================
    public void onChatMessage(String raw) {

        if (!ModConfig.get().berserkerTracker) return;

        String msg = strip(raw);

        // =========================
        // STATE TRANSITIONS
        // =========================
        switch (state) {

            case IDLE -> {
                if (msg.contains(SCAN_TRIGGER)) {
                    state = State.WAITING_START;
                }
            }

            case WAITING_START -> {
                if (msg.contains(P3_START)) {
                    state = State.IN_DUNGEON;
                    resetRun();
                }
            }

            case IN_DUNGEON -> {
                if (msg.contains(P3_START)) {
                    state = State.ACTIVE;

                    section1Active = true;

                    // VERY SHORT WINDOW BEFORE FIRST DEVICE ARRIVES
                    startGraceTicks = 10; // ~0.5s
                }
            }
        }

        // =========================
        // DEVICE EVENT (REAL SOURCE)
        // =========================
        Matcher device = DEVICE_DONE.matcher(msg);

        if (device.find()) {

            String player = device.group(1);

            if (!isValid(player)) return;

            currentBerserker = player;

            if (!berserkerList.contains(player)) {
                berserkerList.add(player);
            }

            berserkerDone = true;

            // FIRST REAL NAME → immediate start message
            tryStartAnnouncement();

            sendPc(ModConfig.get().berserkerMsgStart, player);
        }

        // =========================
        // SECTION END
        // =========================
        if (SEVEN_OF_SEVEN.matcher(msg).find()) {

            sevenCount++;
            section1Active = false;

            if (sevenCount == 1) {

                if (!berserkerDone && !notDoneSent) {
                    sendPc(ModConfig.get().berserkerMsgNotDone, getBest());
                    notDoneSent = true;
                }

            } else if (sevenCount == 2) {

                if (!berserkerDone && !s4Sent) {
                    sendPc(ModConfig.get().berserkerMsgS4, getBest());
                    s4Sent = true;
                }

                state = State.CLEANUP;

                sendListOutput();
            }
        }
    }

    // =========================
    // TICK (allows ultra-fast first detection)
    // =========================
    public void tick() {

        if (startGraceTicks > 0) {
            startGraceTicks--;

            if (startGraceTicks == 0) {
                tryStartAnnouncement();
            }
        }
    }

    // =========================
    // START MESSAGE (REAL NAME ONLY)
    // =========================
    private void tryStartAnnouncement() {

        if (startAnnounced) return;
        if (currentBerserker == null) return;

        startAnnounced = true;

        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player != null) {
            mc.player.sendMessage(
                    Text.literal("§d[MelodyAddons] §fBerserker: §b" + currentBerserker),
                    false
            );
        }
    }

    // =========================
    // LIST OUTPUT
    // =========================
    private void sendListOutput() {

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        mc.player.sendMessage(
                Text.literal("§d[MelodyAddons] §fBerserkers involved: §b"
                        + (berserkerList.isEmpty() ? "None" : String.join(", ", berserkerList))),
                false
        );
    }

    // =========================
    // PC MESSAGE
    // =========================
    private void sendPc(String msg, String bers) {
        if (msg == null) return;

        String finalMsg = msg.replace("(bers)", bers);

        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player != null && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
        }
    }

    // =========================
    // HELPERS
    // =========================
    private String getBest() {
        return currentBerserker != null ? currentBerserker : "Berserker";
    }

    private void resetRun() {
        currentBerserker = null;
        berserkerList.clear();

        berserkerDone = false;
        notDoneSent = false;
        s4Sent = false;

        startAnnounced = false;
        startGraceTicks = 0;

        sevenCount = 0;
        section1Active = false;
    }

    private boolean isValid(String name) {
        return name != null && name.matches("^[A-Za-z0-9_]{3,16}$");
    }

    private String strip(String s) {
        return s == null ? "" : s.replaceAll("§[0-9a-fk-orx]", "").trim();
    }
}