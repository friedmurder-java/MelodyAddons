package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.scoreboard.*;
import net.minecraft.text.Text;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    private static final Pattern DEVICE_DONE = Pattern.compile(
            "(.+) completed a device! \\(\\d+/7\\)",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern SEVEN_OF_SEVEN = Pattern.compile(
            "\\(7/7\\)"
    );
    private static final String P3_START = "Who dares trespass into my domain";
    private static final String SCAN_TRIGGER = "Starting in 2 seconds.";

    private boolean inP3              = false;
    private boolean inS1              = false;
    private boolean berserkerDone     = false;
    private boolean notDoneSent       = false;
    private boolean doneMsgSent       = false;
    private int     sevenOfSevenCount = 0;
    private String  berserkerName     = "Berserker";

    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    public void onChatMessage(String raw) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.berserkerTracker) return;

        if (raw.contains(SCAN_TRIGGER)) {
            berserkerName = scanScoreboardForBerserker();
            sendClientSideMessage("§d[MelodyAddons] §fBerserker: §b" + berserkerName);
            return;
        }

        if (raw.contains(P3_START)) {
            inP3              = true;
            inS1              = true;
            berserkerDone     = false;
            notDoneSent       = false;
            doneMsgSent       = false;
            sevenOfSevenCount = 0;

            if (berserkerName.equals("Berserker")) {
                berserkerName = scanScoreboardForBerserker();
            }
            return;
        }

        if (!inP3) return;

        Matcher mDevice = DEVICE_DONE.matcher(raw);
        if (mDevice.find()) {
            String playerName = mDevice.group(1).trim();
            if (playerName.equalsIgnoreCase(berserkerName)) {
                berserkerDone = true;
                if (!doneMsgSent && ModConfig.nonEmpty(cfg.berserkerMsgStart)) {
                    sendFormattedPc(cfg.berserkerMsgStart);
                    doneMsgSent = true;
                }
            }
        }

        if (SEVEN_OF_SEVEN.matcher(raw).find()) {
            sevenOfSevenCount++;
            if (sevenOfSevenCount == 1) {
                inS1 = false;
                if (!berserkerDone && !notDoneSent && ModConfig.nonEmpty(cfg.berserkerMsgNotDone)) {
                    sendFormattedPc(cfg.berserkerMsgNotDone);
                    notDoneSent = true;
                }
            } else if (sevenOfSevenCount == 2) {
                if (!berserkerDone && ModConfig.nonEmpty(cfg.berserkerMsgS4)) {
                    sendFormattedPc(cfg.berserkerMsgS4);
                }
                inP3 = false;
            }
        }
    }

    private String scanScoreboardForBerserker() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return "Berserker";

        Scoreboard scoreboard = mc.world.getScoreboard();
        ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (objective == null) return "Berserker";

        boolean tagFoundOnScoreboard = false;

        for (ScoreboardEntry entry : scoreboard.getScoreboardEntries(objective)) {
            String line = entry.name().getString();
            String unformattedLine = line.replaceAll("§[0-9a-fk-orx]", "");

            if (unformattedLine.contains("[B]")) {
                tagFoundOnScoreboard = true;
                String name = cleanScoreboardLine(unformattedLine);
                if (!name.isEmpty() && !name.equalsIgnoreCase("You")) return name;
            }
        }

        if (!tagFoundOnScoreboard && mc.player != null) {
            return mc.player.getName().getString();
        }

        return "Berserker";
    }

    private String cleanScoreboardLine(String unformattedLine) {
        // 1. Remove the tag
        String cleaned = unformattedLine.replace("[B]", "").trim();

        // 2. Based on your image, the format is "[B] Name Health"
        // We split by any whitespace and take the first element (the name)
        String[] parts = cleaned.split("\\s+");
        if (parts.length > 0) {
            cleaned = parts[0];
        }

        if (cleaned.equalsIgnoreCase("You")) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) return mc.player.getName().getString();
        }

        return cleaned;
    }

    private void sendFormattedPc(String message) {
        String finalMsg = message.replace("(berserker)", berserkerName);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.getNetworkHandler() != null)
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
    }

    private void sendClientSideMessage(String message) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(message), false);
        }
    }
}
