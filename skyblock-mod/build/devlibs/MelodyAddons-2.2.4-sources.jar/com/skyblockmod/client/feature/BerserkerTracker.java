package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    // =========================
    // SINGLETON (FOR MIXINS)
    // =========================
    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    // =========================
    // STATE
    // =========================
    private boolean s1Active = false;
    private boolean s4Active = false;

    private boolean bersDidDevice = false;

    private boolean msgNotDoneSent = false;
    private boolean msgS4Sent = false;

    private int sevenCount = 0;

    // =========================
    // NAME STORAGE (STABLE)
    // =========================
    private String currentBers = null;

    // =========================
    // DEVICE DETECTION
    // =========================
    private static final Pattern DEVICE_DONE =
            Pattern.compile("([A-Za-z0-9_]{1,16}).*completed a device", Pattern.CASE_INSENSITIVE);

    // =========================
    // CHAT HANDLER
    // =========================
    public void onChatMessage(String raw) {

        if (!ModConfig.get().berserkerTracker) return;

        String msg = strip(raw);

        // =========================
        // DEVICE EVENT (CAPTURE NAME)
        // =========================
        Matcher m = DEVICE_DONE.matcher(msg);

        if (m.find()) {

            String player = m.group(1);

            if (!isValid(player)) return;

            currentBers = player;
            bersDidDevice = true;
        }

        // =========================
        // PHASE TRACKING (7/7)
        // =========================
        if (msg.contains("(7/7)")) {

            sevenCount++;

            // =========================
            // END S1
            // =========================
            if (sevenCount == 1) {

                s1Active = false;

                if (!bersDidDevice && !msgNotDoneSent) {
                    msgNotDoneSent = true;
                    sendPc(ModConfig.get().berserkerMsgNotDone, getBers());
                }
            }

            // =========================
            // START S4
            // =========================
            else if (sevenCount == 2) {

                s4Active = true;

                if (!bersDidDevice && !msgS4Sent) {
                    msgS4Sent = true;
                    sendPc(ModConfig.get().berserkerMsgS4, getBers());
                }
            }
        }
    }

    // =========================
    // PARTY CHAT SENDER
    // =========================
    private void sendPc(String msg, String bers) {

        if (msg == null) return;

        String finalMsg = msg.replace("(bers)", bers);

        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player != null && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
        }
    }

    // =========================
    // HELPERS
    // =========================
    private String getBers() {
        return currentBers != null ? currentBers : "Berserker";
    }

    private boolean isValid(String name) {
        return name != null && name.matches("^[A-Za-z0-9_]{1,16}$");
    }

    private String strip(String s) {
        return s == null ? "" : s.replaceAll("§[0-9a-fk-orx]", "").trim();
    }
}