package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.scoreboard.*;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    private static final Pattern DEVICE_DONE = Pattern.compile(
            "(.+) completed a device! \\(\\d+/7\\)",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern SEVEN_OF_SEVEN = Pattern.compile(
            "\\(7/7\\)"
    );
    private static final String P3_START = "Who dares trespass into my domain";
    private static final String SCAN_TRIGGER = "Starting in 2 seconds.";

    private boolean inP3              = false;
    private boolean inS1              = false;
    private boolean berserkerDone     = false;
    private boolean notDoneSent       = false;
    private boolean doneMsgSent       = false;
    private int     sevenOfSevenCount = 0;

    private final List<String> berserkerNames = new ArrayList<>();
    private String lastActiveBerserker = "Berserker";

    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    public void onChatMessage(String raw) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.berserkerTracker) return;

        if (raw.contains(SCAN_TRIGGER)) {
            berserkerNames.clear();
            scanForBerserkers();

            sendClientSideMessage("§d[MelodyAddons] §fBerserkers detected:");
            if (berserkerNames.isEmpty()) {
                sendClientSideMessage(" §7- None (Using Self)");
                if (MinecraftClient.getInstance().player != null)
                    berserkerNames.add(MinecraftClient.getInstance().player.getName().getString());
            } else {
                for (String name : berserkerNames) {
                    sendClientSideMessage(" §6[B] §b" + name);
                }
            }
            return;
        }

        if (raw.contains(P3_START)) {
            inP3              = true;
            inS1              = true;
            berserkerDone     = false;
            notDoneSent       = false;
            doneMsgSent       = false;
            sevenOfSevenCount = 0;
            return;
        }

        if (!inP3) return;

        Matcher mDevice = DEVICE_DONE.matcher(raw);
        if (mDevice.find()) {
            String playerName = mDevice.group(1).trim();

            if (isFoundBerserker(playerName)) {
                berserkerDone = true;
                lastActiveBerserker = playerName;

                if (!doneMsgSent && ModConfig.nonEmpty(cfg.berserkerMsgStart)) {
                    sendFormattedPc(cfg.berserkerMsgStart, lastActiveBerserker);
                    doneMsgSent = true;
                }
            }
            return;
        }

        if (SEVEN_OF_SEVEN.matcher(raw).find()) {
            sevenOfSevenCount++;
            if (sevenOfSevenCount == 1) {
                inS1 = false;
                if (!berserkerDone && !notDoneSent && ModConfig.nonEmpty(cfg.berserkerMsgNotDone)) {
                    sendFormattedPc(cfg.berserkerMsgNotDone, lastActiveBerserker.equals("Berserker") && !berserkerNames.isEmpty() ? berserkerNames.get(0) : lastActiveBerserker);
                    notDoneSent = true;
                }
            } else if (sevenOfSevenCount == 2) {
                if (!berserkerDone && ModConfig.nonEmpty(cfg.berserkerMsgS4)) {
                    sendFormattedPc(cfg.berserkerMsgS4, lastActiveBerserker.equals("Berserker") && !berserkerNames.isEmpty() ? berserkerNames.get(0) : lastActiveBerserker);
                }
                inP3 = false;
            }
        }
    }

    private void scanForBerserkers() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;

        Scoreboard scoreboard = mc.world.getScoreboard();
        ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (objective == null) return;

        for (ScoreboardEntry entry : scoreboard.getScoreboardEntries(objective)) {
            String owner = entry.owner().replaceAll("§[0-9a-fk-orx]", "");
            if (owner.contains("[B]")) {
                String name = cleanName(owner);
                if (!name.isEmpty() && !berserkerNames.contains(name)) {
                    berserkerNames.add(name);
                }
            }
        }
    }

    private String cleanName(String raw) {
        String cleaned = raw.replace("[B]", "").trim();
        String[] parts = cleaned.split("\\s+");
        if (parts.length > 0) cleaned = parts[0];

        if (cleaned.equalsIgnoreCase("You") && MinecraftClient.getInstance().player != null) {
            return MinecraftClient.getInstance().player.getName().getString();
        }
        return cleaned;
    }

    private boolean isFoundBerserker(String playerName) {
        for (String bName : berserkerNames) {
            if (bName.equalsIgnoreCase(playerName)) return true;
        }
        return false;
    }

    private void sendFormattedPc(String message, String nameToUse) {
        String finalMsg = message.replace("(berserker)", nameToUse);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.getNetworkHandler() != null)
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
    }

    private void sendClientSideMessage(String message) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(message), false);
        }
    }
}
