package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    // =========================
    // STATE MACHINE
    // =========================
    private enum State {
        IDLE,
        WAITING_START,
        IN_DUNGEON,
        ACTIVE,
        CLEANUP
    }

    private State state = State.IDLE;

    // =========================
    // SECTION CONTROL
    // =========================
    private boolean section1Active = false;

    // =========================
    // PATTERNS
    // =========================
    private static final String SCAN_TRIGGER = "Starting in 1 second.";
    private static final String P3_START = "Who dares trespass into my domain";

    private static final Pattern DEVICE_DONE =
            Pattern.compile("([A-Za-z0-9_]{3,16}).*completed a device! \\(\\d+/7\\)", Pattern.CASE_INSENSITIVE);

    private static final Pattern SEVEN_OF_SEVEN =
            Pattern.compile("\\(7/7\\)");

    // =========================
    // DATA
    // =========================
    private final List<String> berserkerList = new ArrayList<>();

    private String currentBerserker = null;

    private boolean berserkerDone = false;
    private boolean notDoneSent = false;
    private boolean s4Sent = false;

    private int sevenCount = 0;

    // =========================
    // SINGLETON
    // =========================
    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    // =========================
    // CHAT HANDLER
    // =========================
    public void onChatMessage(String raw) {

        if (!ModConfig.get().berserkerTracker) return;

        String msg = strip(raw);

        // =========================
        // DEBUG INPUT
        // =========================
        debug("CHAT: " + msg);

        // =========================
        // STATE TRANSITIONS
        // =========================
        switch (state) {

            case IDLE -> {
                if (msg.contains(SCAN_TRIGGER)) {
                    state = State.WAITING_START;
                    debug("STATE → WAITING_START");
                }
            }

            case WAITING_START -> {
                if (msg.contains(P3_START)) {
                    state = State.IN_DUNGEON;
                    resetRun();
                    debug("STATE → IN_DUNGEON");
                }
            }

            case IN_DUNGEON -> {
                if (msg.contains(P3_START)) {
                    state = State.ACTIVE;
                    section1Active = true;
                    debug("SECTION 1 ACTIVE");
                }
            }
        }

        // =========================
        // DEVICE EVENT (ONLY REAL SOURCE)
        // =========================
        Matcher device = DEVICE_DONE.matcher(msg);

        if (device.find()) {

            String player = device.group(1);

            debug("DEVICE DETECTED: " + player);

            if (isValid(player)) {

                currentBerserker = player;

                if (!berserkerList.contains(player)) {
                    berserkerList.add(player);
                    debug("ADDED TO LIST: " + player);
                }

                // STRICT RULE: ONLY SECTION 1
                if (section1Active && !berserkerDone) {

                    berserkerDone = true;

                    sendPc(ModConfig.get().berserkerMsgStart, currentBerserker);

                    debug("FIRST MSG SENT → " + currentBerserker);
                }
            }
        }

        // =========================
        // SECTION END (7/7)
        // =========================
        if (SEVEN_OF_SEVEN.matcher(msg).find()) {

            sevenCount++;
            section1Active = false;

            debug("7/7 DETECTED → SECTION END");

            if (sevenCount == 1) {

                if (!berserkerDone && !notDoneSent) {
                    sendPc(ModConfig.get().berserkerMsgNotDone, getBest());
                    notDoneSent = true;
                    debug("NOT DONE SENT");
                }

            } else if (sevenCount == 2) {

                if (!berserkerDone && !s4Sent) {
                    sendPc(ModConfig.get().berserkerMsgS4, getBest());
                    s4Sent = true;
                    debug("S4 SENT");
                }

                state = State.CLEANUP;

                sendListOutput();
                debug("RUN FINISHED");
            }
        }
    }

    // =========================
    // ALWAYS-ON DEBUG
    // =========================
    private void debug(String msg) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(
                    Text.literal("§7[DBG] §f" + msg),
                    false
            );
        }
    }

    // =========================
    // TICK
    // =========================
    public void tick() {
        // reserved
    }

    // =========================
    // LIST OUTPUT
    // =========================
    private void sendListOutput() {

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        if (berserkerList.isEmpty()) {
            mc.player.sendMessage(
                    Text.literal("§d[MelodyAddons] §fBerserkers involved: §7None"),
                    false
            );
            return;
        }

        mc.player.sendMessage(
                Text.literal("§d[MelodyAddons] §fBerserkers involved: §b"
                        + String.join(", ", berserkerList)),
                false
        );
    }

    // =========================
    // MESSAGE SENDING
    // =========================
    private void sendPc(String msg, String bers) {
        if (msg == null) return;

        String finalMsg = msg
                .replace("(bers)", bers)
                .replace("(berserker)", bers);

        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player != null && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
        }
    }

    // =========================
    // HELPERS
    // =========================
    private String getBest() {
        return currentBerserker != null ? currentBerserker : "Berserker";
    }

    private void resetRun() {
        currentBerserker = null;
        berserkerList.clear();

        berserkerDone = false;
        notDoneSent = false;
        s4Sent = false;

        sevenCount = 0;
        section1Active = false;
    }

    private boolean isValid(String name) {
        return name != null && name.matches("^[A-Za-z0-9_]{3,16}$");
    }

    private String strip(String s) {
        return s == null ? "" : s.replaceAll("§[0-9a-fk-orx]", "").trim();
    }
}