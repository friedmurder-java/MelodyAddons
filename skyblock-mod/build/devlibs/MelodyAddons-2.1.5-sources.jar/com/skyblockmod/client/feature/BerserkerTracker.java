package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    // =========================
    // STATE MACHINE
    // =========================
    private enum State {
        IDLE,
        WAITING_START,
        IN_DUNGEON,
        PHASE_3,
        ACTIVE,
        CLEANUP
    }

    private State state = State.IDLE;

    // =========================
    // TRIGGERS
    // =========================
    private static final String P3_START = "Who dares trespass into my domain";
    private static final String SCAN_TRIGGER = "Starting in 1 second.";

    // =========================
    // PATTERNS
    // =========================
    private static final Pattern DEVICE_DONE =
            Pattern.compile("([A-Za-z0-9_]{3,16}).*completed a device! \\(\\d+/7\\)", Pattern.CASE_INSENSITIVE);

    private static final Pattern SEVEN_OF_SEVEN =
            Pattern.compile("\\(7/7\\)");

    // =========================
    // DATA
    // =========================
    private final List<String> berserkerList = new ArrayList<>();

    private String currentBerserker = null;

    private boolean berserkerDone = false;
    private boolean notDoneSent = false;
    private boolean s4Sent = false;

    private int sevenCount = 0;
    private int readyTicks = 0;

    // =========================
    // SINGLETON
    // =========================
    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    // =========================
    // CHAT HANDLER
    // =========================
    public void onChatMessage(String raw) {
        if (!ModConfig.get().berserkerTracker) return;

        String msg = strip(raw);

        switch (state) {

            case IDLE -> {
                if (msg.contains(SCAN_TRIGGER)) {
                    state = State.WAITING_START;
                }
            }

            case WAITING_START -> {
                if (msg.contains(P3_START)) {
                    state = State.IN_DUNGEON;
                    resetRun();
                }
            }

            case IN_DUNGEON -> {
                if (msg.contains(P3_START)) {
                    state = State.PHASE_3;
                }
            }

            case PHASE_3 -> {
                readyTicks = 10;
                state = State.ACTIVE;
            }
        }

        // =========================
        // DEVICE EVENT (ONLY TRUE SOURCE)
        // =========================
        Matcher device = DEVICE_DONE.matcher(msg);

        if (device.find()) {
            String player = device.group(1);

            if (isValid(player)) {

                currentBerserker = player;

                // add ONLY real confirmed participants
                if (!berserkerList.contains(player)) {
                    berserkerList.add(player);
                }

                berserkerDone = true;

                sendPc(ModConfig.get().berserkerMsgStart, currentBerserker);
            }
        }

        // =========================
        // 7/7 LOGIC
        // =========================
        if (SEVEN_OF_SEVEN.matcher(msg).find()) {

            sevenCount++;

            if (sevenCount == 1) {

                if (!berserkerDone && !notDoneSent) {
                    sendPc(ModConfig.get().berserkerMsgNotDone, getBest());
                    notDoneSent = true;
                }

            } else if (sevenCount == 2) {

                if (!berserkerDone && !s4Sent) {
                    sendPc(ModConfig.get().berserkerMsgS4, getBest());
                    s4Sent = true;
                }

                // =========================
                // SAFE LIST OUTPUT
                // =========================
                sendListOutput();

                state = State.CLEANUP;
            }
        }
    }

    // =========================
    // TICK
    // =========================
    public void tick() {

        if (readyTicks > 0) {
            readyTicks--;
            return;
        }

        if (state != State.ACTIVE) return;

        // no unsafe scanning anymore
    }

    // =========================
    // SAFE LIST OUTPUT
    // =========================
    private void sendListOutput() {

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        if (berserkerList.isEmpty()) {
            mc.player.sendMessage(
                    Text.literal("§d[MelodyAddons] §fBerserkers involved: §7None"),
                    false
            );
            return;
        }

        String msg = String.join(", ", berserkerList);

        mc.player.sendMessage(
                Text.literal("§d[MelodyAddons] §fBerserkers involved: §b" + msg),
                false
        );
    }

    // =========================
    // MESSAGE SENDING
    // =========================
    private void sendPc(String msg, String bers) {
        if (msg == null) return;

        String finalMsg = msg
                .replace("(bers)", bers)
                .replace("(berserker)", bers);

        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player != null && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
        }
    }

    // =========================
    // HELPERS
    // =========================
    private String getBest() {
        return currentBerserker != null ? currentBerserker : "Berserker";
    }

    private void resetRun() {
        currentBerserker = null;
        berserkerList.clear();

        berserkerDone = false;
        notDoneSent = false;
        s4Sent = false;

        sevenCount = 0;
    }

    private boolean isValid(String name) {
        return name != null && name.matches("^[A-Za-z0-9_]{3,16}$");
    }

    private String strip(String s) {
        return s == null ? "" : s.replaceAll("§[0-9a-fk-orx]", "").trim();
    }
}