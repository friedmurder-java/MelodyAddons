package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    // =========================
    // SINGLETON (DO NOT TOUCH)
    // =========================
    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    // =========================
    // STATE (UNCHANGED LOGIC)
    // =========================
    private boolean dungeonStarted = false;
    private boolean startMessageSent = false;

    private int startDelayTicks = 0;

    private boolean s1Active = false;
    private boolean s4Active = false;

    private boolean bersDidDevice = false;

    private boolean msgNotDoneSent = false;
    private boolean msgS4Sent = false;

    private int sevenCount = 0;

    // =========================
    // NAME STORAGE FIX
    // =========================
    private String currentBers = null;
    private String lastKnownBers = null;

    // =========================
    // PATTERN
    // =========================
    private static final Pattern DEVICE_DONE =
            Pattern.compile("([A-Za-z0-9_]{3,16}).*completed a device! \\(\\d+/7\\)", Pattern.CASE_INSENSITIVE);

    private static final String DUNGEON_START = "Starting in 1 second.";

    // =========================
    // CHAT HANDLER
    // =========================
    public void onChatMessage(String raw) {

        if (!ModConfig.get().berserkerTracker) return;

        String msg = strip(raw);

        // =========================
        // DUNGEON START
        // =========================
        if (msg.contains(DUNGEON_START)) {

            dungeonStarted = true;

            s1Active = true;
            s4Active = false;

            bersDidDevice = false;
            sevenCount = 0;

            msgNotDoneSent = false;
            msgS4Sent = false;

            startDelayTicks = 60; // 3 seconds
        }

        // =========================
        // DEVICE EVENT (NAME FIX HERE)
        // =========================
        Matcher m = DEVICE_DONE.matcher(msg);

        if (m.find()) {

            String player = m.group(1);

            if (!isValid(player)) return;

            currentBers = player;
            lastKnownBers = player; // 🔥 FIX: persistent storage
            bersDidDevice = true;
        }

        // =========================
        // (7/7) LOGIC (UNCHANGED)
        // =========================
        if (msg.contains("(7/7)")) {

            sevenCount++;

            if (sevenCount == 1) {

                s1Active = false;

                if (!bersDidDevice && !msgNotDoneSent) {
                    msgNotDoneSent = true;
                    sendPc(ModConfig.get().berserkerMsgNotDone, getBers());
                }
            }

            else if (sevenCount == 2) {

                s4Active = true;

                if (!bersDidDevice && !msgS4Sent) {
                    msgS4Sent = true;
                    sendPc(ModConfig.get().berserkerMsgS4, getBers());
                }
            }
        }
    }

    // =========================
    // TICK (UNCHANGED LOGIC)
    // =========================
    public void tick() {

        if (startDelayTicks > 0) {
            startDelayTicks--;

            if (startDelayTicks == 0 && dungeonStarted && !startMessageSent) {

                startMessageSent = true;

                MinecraftClient mc = MinecraftClient.getInstance();

                if (mc.player != null) {

                    String name = (lastKnownBers != null)
                            ? lastKnownBers
                            : "Berserker";

                    mc.player.sendMessage(
                            Text.literal("§d[MelodyAddons] §fBerserker: §b" + name),
                            false
                    );
                }
            }
        }
    }

    // =========================
    // PARTY CHAT
    // =========================
    private void sendPc(String msg, String bers) {

        if (msg == null) return;

        String finalMsg = msg.replace("(bers)", bers);

        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player != null && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
        }
    }

    // =========================
    // HELPERS
    // =========================
    private String getBers() {
        return (lastKnownBers != null) ? lastKnownBers : "Berserker";
    }

    private boolean isValid(String name) {
        return name != null && name.matches("^[A-Za-z0-9_]{3,16}$");
    }

    private String strip(String s) {
        return s == null ? "" : s.replaceAll("§[0-9a-fk-orx]", "").trim();
    }
}