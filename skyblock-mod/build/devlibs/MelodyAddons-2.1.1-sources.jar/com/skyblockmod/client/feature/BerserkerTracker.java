package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.*;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    // =========================
    // STATE MACHINE
    // =========================
    private enum State {
        IDLE,
        WAITING_START,
        IN_DUNGEON,
        PHASE_3,
        ACTIVE,
        CLEANUP
    }

    private State state = State.IDLE;

    // =========================
    // TRIGGERS
    // =========================
    private static final String P3_START = "Who dares trespass into my domain";
    private static final String SCAN_TRIGGER = "Starting in 1 second.";

    // =========================
    // PATTERNS
    // =========================
    private static final Pattern VALID_NAME =
            Pattern.compile("^[A-Za-z0-9_]{3,16}$");

    private static final Pattern DEVICE_DONE =
            Pattern.compile("([A-Za-z0-9_]{3,16}).*completed a device! \\(\\d+/7\\)", Pattern.CASE_INSENSITIVE);

    private static final Pattern SEVEN_OF_SEVEN =
            Pattern.compile("\\(7/7\\)");

    // =========================
    // DATA
    // =========================
    private final List<String> berserkerNames = new ArrayList<>();

    private String lastBerserker = null;

    private boolean berserkerDone = false;
    private boolean notDoneSent = false;
    private boolean s4Sent = false;

    private int sevenCount = 0;
    private int readyTicks = 0;

    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    // =========================
    // CHAT HANDLER
    // =========================
    public void onChatMessage(String raw) {
        if (!ModConfig.get().berserkerTracker) return;

        String clean = strip(raw);

        switch (state) {

            case IDLE -> {
                if (clean.contains(SCAN_TRIGGER)) {
                    state = State.WAITING_START;
                }
            }

            case WAITING_START -> {
                if (clean.contains(P3_START)) {
                    state = State.IN_DUNGEON;
                    resetRun();
                }
            }

            case IN_DUNGEON -> {
                if (clean.contains(P3_START)) {
                    state = State.PHASE_3;
                }
            }

            case PHASE_3 -> {
                readyTicks = 10;
                state = State.ACTIVE;
            }
        }

        // =========================
        // DEVICE EVENT
        // =========================
        Matcher device = DEVICE_DONE.matcher(clean);

        if (device.find()) {
            String name = device.group(1);

            if (isValid(name)) {
                berserkerDone = true;
                lastBerserker = name;

                sendPc(ModConfig.get().berserkerMsgStart, name);
            }
        }

        // =========================
        // 7/7 LOGIC
        // =========================
        if (SEVEN_OF_SEVEN.matcher(clean).find()) {

            sevenCount++;

            if (sevenCount == 1) {

                if (!berserkerDone && !notDoneSent) {
                    sendPc(ModConfig.get().berserkerMsgNotDone, getBest());
                    notDoneSent = true;
                }

            } else if (sevenCount == 2) {

                if (!berserkerDone && !s4Sent) {
                    sendPc(ModConfig.get().berserkerMsgS4, getBest());
                    s4Sent = true;
                }

                state = State.CLEANUP;
            }
        }
    }

    // =========================
    // TICK LOOP
    // =========================
    public void tick() {

        if (readyTicks > 0) {
            readyTicks--;
            return;
        }

        if (state != State.ACTIVE) return;

        scan();
    }

    // =========================
    // SCAN LOGIC
    // =========================
    private void scan() {
        berserkerNames.clear();

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.getNetworkHandler() == null) return;

        Scoreboard scoreboard = mc.world.getScoreboard();

        // =====================
        // SCOREBOARD SCAN
        // =====================
        for (Team team : scoreboard.getTeams()) {

            for (String raw : team.getPlayerList()) {

                String name = strip(raw);

                if (!isValid(name)) continue;

                if (!berserkerNames.contains(name)) {
                    berserkerNames.add(name);
                }
            }
        }

        // =====================
        // TABLIST FALLBACK
        // =====================
        if (berserkerNames.isEmpty()) {
            for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {

                String name = e.getProfile().name();

                if (isValid(name)) {
                    berserkerNames.add(name);
                }
            }
        }
    }

    // =========================
    // UTILITIES
    // =========================
    private void sendPc(String msg, String name) {
        if (msg == null) return;

        String finalMsg = msg
                .replace("(bers)", name)
                .replace("(berserker)", name);

        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player != null && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
        }
    }

    private String getBest() {
        if (lastBerserker != null) return lastBerserker;
        return berserkerNames.isEmpty() ? "Berserker" : berserkerNames.get(0);
    }

    private void resetRun() {
        berserkerDone = false;
        notDoneSent = false;
        s4Sent = false;
        sevenCount = 0;
        lastBerserker = null;
    }

    private boolean isValid(String name) {
        return name != null && VALID_NAME.matcher(name).matches();
    }

    private String strip(String s) {
        return s == null ? "" : s.replaceAll("§[0-9a-fk-orx]", "").trim();
    }
}