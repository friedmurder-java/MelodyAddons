package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.*;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BerserkerTracker {

    private static final String P3_START = "Who dares trespass into my domain";
    private static final String SCAN_TRIGGER = "Starting in 1 second.";

    private static final Set<String> berserkerNames = new HashSet<>();

    private boolean inP3 = false;
    private int scanTimer = -1;

    private String lastName = null;

    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    public void tick() {
        if (scanTimer > 0) {
            scanTimer--;
        } else if (scanTimer == 0) {
            boolean found = scan();
            scanTimer = found ? -1 : 20;
        }
    }

    public void onChatMessage(String raw) {
        if (!ModConfig.get().berserkerTracker) return;

        if (raw.contains(SCAN_TRIGGER)) {
            scanTimer = 60; // wait for Hypixel to populate data
            return;
        }

        if (raw.contains(P3_START)) {
            inP3 = true;
            berserkerNames.clear();
            lastName = null;
        }
    }

    private boolean scan() {
        berserkerNames.clear();

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.getNetworkHandler() == null) return false;

        // =========================
        // SCOREBOARD SCAN
        // =========================
        Scoreboard scoreboard = mc.world.getScoreboard();

        for (Team team : scoreboard.getTeams()) {

            for (String rawName : team.getPlayerList()) {

                String name = rawName.replaceAll("§[0-9a-fk-orx]", "").trim();

                if (!isValidName(name)) continue;

                // IMPORTANT: reject fake dungeon IDs
                if (isFakeEntry(name)) continue;

                if (isActuallyOnline(mc, name)) {
                    berserkerNames.add(name);
                }
            }
        }

        // =========================
        // TABLIST FALLBACK
        // =========================
        if (berserkerNames.isEmpty()) {
            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {

                String name = entry.getProfile().name();

                if (isValidName(name)) {
                    berserkerNames.add(name);
                }
            }
        }

        // =========================
        // OUTPUT
        // =========================
        if (!berserkerNames.isEmpty() && mc.player != null) {

            String msg = String.join(", ", berserkerNames);

            mc.player.sendMessage(
                    Text.literal("§d[MelodyAddons] §fBerserker: §b" + msg),
                    false
            );

            return true;
        }

        return false;
    }

    // -------------------------
    // VALIDATION HELPERS
    // -------------------------

    private boolean isValidName(String name) {
        return name != null &&
                name.matches("^[A-Za-z0-9_]{3,16}$");
    }

    private boolean isFakeEntry(String name) {
        return name.length() < 3 ||
                name.toLowerCase().contains("health") ||
                name.matches(".*[0-9]{6,}.*"); // catches dungeon dummy IDs like s1t7nz72bs
    }

    private boolean isActuallyOnline(MinecraftClient mc, String name) {
        for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
            if (e.getProfile().name().equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }
}