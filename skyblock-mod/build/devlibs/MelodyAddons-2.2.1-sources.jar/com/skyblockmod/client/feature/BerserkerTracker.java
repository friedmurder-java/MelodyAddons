package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    // =========================
    // SINGLETON (for mixins)
    // =========================
    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    // =========================
    // STATE
    // =========================
    private boolean dungeonStarted = false;
    private boolean infoMessageSent = false;

    private int startDelayTicks = 0;

    private boolean s1Active = false;
    private boolean s4Active = false;

    private boolean bersDidDevice = false;

    private boolean msgNotDoneSent = false;
    private boolean msgS4Sent = false;

    private int sevenCount = 0;

    private String currentBers = null;

    // =========================
    // PATTERNS
    // =========================
    private static final Pattern DEVICE_DONE =
            Pattern.compile("([A-Za-z0-9_]{3,16}).*completed a device! \\(\\d+/7\\)", Pattern.CASE_INSENSITIVE);

    private static final String START = "Starting in 1 second.";

    // =========================
    // CHAT
    // =========================
    public void onChatMessage(String raw) {

        String msg = strip(raw);

        // =========================
        // DUNGEON START
        // =========================
        if (msg.contains(START)) {

            dungeonStarted = true;

            s1Active = true;
            s4Active = false;

            bersDidDevice = false;
            sevenCount = 0;

            msgNotDoneSent = false;
            msgS4Sent = false;

            // start 3s delay (60 ticks)
            startDelayTicks = 60;
        }

        // =========================
        // DEVICE EVENT
        // =========================
        Matcher m = DEVICE_DONE.matcher(msg);

        if (m.find()) {

            String player = m.group(1);

            if (!isValid(player)) return;

            currentBers = player;
            bersDidDevice = true;
        }

        // =========================
        // (7/7) PHASES
        // =========================
        if (msg.contains("(7/7)")) {

            sevenCount++;

            if (sevenCount == 1) {

                s1Active = false;

                if (!bersDidDevice && !msgNotDoneSent) {
                    msgNotDoneSent = true;
                    sendPc(ModConfig.get().berserkerMsgNotDone, getBers());
                }
            }

            else if (sevenCount == 2) {

                s4Active = true;

                if (!bersDidDevice && !msgS4Sent) {
                    msgS4Sent = true;
                    sendPc(ModConfig.get().berserkerMsgS4, getBers());
                }
            }
        }
    }

    // =========================
    // TICK (3s DELAY INFO MESSAGE)
    // =========================
    public void tick() {

        if (startDelayTicks > 0) {
            startDelayTicks--;

            if (startDelayTicks == 0 && dungeonStarted && !infoMessageSent) {

                infoMessageSent = true;

                MinecraftClient mc = MinecraftClient.getInstance();

                if (mc.player != null) {
                    mc.player.sendMessage(
                            net.minecraft.text.Text.literal(
                                    "§d[MelodyAddons] §fBerserker: §b" + getBers()
                            ),
                            false
                    );
                }
            }
        }
    }

    // =========================
    // PARTY CHAT (CONFIG ONLY)
    // =========================
    private void sendPc(String msg, String bers) {

        if (msg == null) return;

        String finalMsg = msg.replace("(bers)", bers);

        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.player != null && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
        }
    }

    // =========================
    // HELPERS
    // =========================
    private String getBers() {
        return currentBers != null ? currentBers : "Berserker";
    }

    private boolean isValid(String name) {
        return name != null && name.matches("^[A-Za-z0-9_]{3,16}$");
    }

    private String strip(String s) {
        return s == null ? "" : s.replaceAll("§[0-9a-fk-orx]", "").trim();
    }
}