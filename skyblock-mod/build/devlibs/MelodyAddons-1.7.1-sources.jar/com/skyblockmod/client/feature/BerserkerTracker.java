package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.*;
import net.minecraft.text.Text;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    private static final Pattern DEVICE_DONE = Pattern.compile(
            "(.+) completed a device \\(\\d+/7\\)",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern SEVEN_OF_SEVEN = Pattern.compile(
            "\\(7/7\\)"
    );
    private static final String P3_START = "Who dares trespass into my domain";

    private boolean inP3              = false;
    private boolean inS1              = false;
    private boolean berserkerDone     = false;
    private boolean notDoneSent       = false;
    private boolean doneMsgSent       = false;
    private int     sevenOfSevenCount = 0;
    private String  berserkerName     = "Berserker";

    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    public void onChatMessage(String raw) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.berserkerTracker) return;

        if (raw.contains(P3_START)) {
            inP3              = true;
            inS1              = true;
            berserkerDone     = false;
            notDoneSent       = false;
            doneMsgSent       = false;
            sevenOfSevenCount = 0;
            berserkerName     = findBerserker();
            return;
        }

        if (!inP3) return;

        if (inS1) {
            Matcher mDevice = DEVICE_DONE.matcher(raw);
            if (mDevice.find()) {
                String playerName = mDevice.group(1).trim();
                if (isBerserker(playerName)) {
                    berserkerDone = true;
                    berserkerName = playerName;

                    if (!doneMsgSent && ModConfig.nonEmpty(cfg.berserkerMsgStart)) {
                        sendFormattedPc(cfg.berserkerMsgStart);
                        doneMsgSent = true;
                    }
                    return;
                }
            }
        }

        if (SEVEN_OF_SEVEN.matcher(raw).find()) {
            sevenOfSevenCount++;

            if (sevenOfSevenCount == 1) {
                inS1 = false;
                if (!berserkerDone && !notDoneSent && ModConfig.nonEmpty(cfg.berserkerMsgNotDone)) {
                    sendFormattedPc(cfg.berserkerMsgNotDone);
                    notDoneSent = true;
                }
            } else if (sevenOfSevenCount == 2) {
                if (!berserkerDone && ModConfig.nonEmpty(cfg.berserkerMsgS4)) {
                    sendFormattedPc(cfg.berserkerMsgS4);
                }
                inP3 = false;
            }
        }
    }

    private String findBerserker() {
        MinecraftClient mc = MinecraftClient.getInstance();
        String fromScore = fetchBerserkerFromScoreboard();
        if (!fromScore.equalsIgnoreCase("Berserker")) return fromScore;

        String fromTab = fetchBerserkerFromTab();
        if (!fromTab.equalsIgnoreCase("Berserker")) return fromTab;

        // Self-detection: If we can't find [B] anywhere, assume YOU are the Berserker
        if (mc.player != null) return mc.player.getName().getString();

        return "Berserker";
    }

    private String fetchBerserkerFromScoreboard() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return "Berserker";
        Scoreboard scoreboard = mc.world.getScoreboard();
        ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (objective == null) return "Berserker";

        for (ScoreboardEntry entry : scoreboard.getScoreboardEntries(objective)) {
            String line = entry.name().getString();
            if (line.contains("[B]")) return cleanName(line);
        }
        return "Berserker";
    }

    private String fetchBerserkerFromTab() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null) return "Berserker";
        for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
            Text displayName = entry.getDisplayName();
            if (displayName != null && displayName.getString().contains("[B]")) {
                return entry.getProfile().name();
            }
        }
        return "Berserker";
    }

    private String cleanName(String line) {
        String cleaned = line.replace("[B]", "").replaceAll("§[0-9a-fk-or]", "").trim();
        if (cleaned.contains(":")) {
            String[] split = cleaned.split(":");
            if (split.length > 0) cleaned = split[0].trim();
        }
        return cleaned;
    }

    private boolean isBerserker(String playerName) {
        if (playerName.equalsIgnoreCase(berserkerName)) return true;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && playerName.equalsIgnoreCase(mc.player.getName().getString())) {
            return true; // If name in chat matches your name, you are the Berserker triggering it
        }
        return false;
    }

    private void sendFormattedPc(String message) {
        String finalMsg = message.replace("(berserker)", berserkerName);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.getNetworkHandler() != null)
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
    }
}
