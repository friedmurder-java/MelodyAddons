package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    private static final Pattern DEVICE_DONE = Pattern.compile(
            "(.+) completed a device \\(\\d+/7\\)",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern SEVEN_OF_SEVEN = Pattern.compile(
            "\\(7/7\\)"
    );
    private static final String P3_START = "Who dares trespass into my domain";

    private boolean inP3              = false;
    private boolean inS1              = false;
    private boolean berserkerDone     = false;
    private boolean notDoneSent       = false;
    private boolean doneMsgSent       = false;
    private int     sevenOfSevenCount = 0;
    private String  berserkerName     = "Berserker";

    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    public void onChatMessage(String raw) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.berserkerTracker) return;

        if (raw.contains(P3_START)) {
            inP3              = true;
            inS1              = true;
            berserkerDone     = false;
            notDoneSent       = false;
            doneMsgSent       = false;
            sevenOfSevenCount = 0;
            berserkerName     = fetchBerserkerName();
            return;
        }

        if (!inP3) return;

        if (inS1) {
            Matcher mDevice = DEVICE_DONE.matcher(raw);
            if (mDevice.find()) {
                String playerName = mDevice.group(1).trim();
                if (isBerserker(playerName)) {
                    berserkerDone = true;
                    berserkerName = playerName;

                    if (!doneMsgSent && ModConfig.nonEmpty(cfg.berserkerMsgStart)) {
                        String msg = cfg.berserkerMsgStart.replace("(berserker)", berserkerName);
                        sendPc(msg);
                        doneMsgSent = true;
                    }
                }
                return;
            }
        }

        if (SEVEN_OF_SEVEN.matcher(raw).find()) {
            sevenOfSevenCount++;

            if (sevenOfSevenCount == 1) {
                inS1 = false;
                if (!berserkerDone && !notDoneSent && ModConfig.nonEmpty(cfg.berserkerMsgNotDone)) {
                    String msg = cfg.berserkerMsgNotDone.replace("(berserker)", berserkerName);
                    sendPc(msg);
                    notDoneSent = true;
                }
            } else if (sevenOfSevenCount == 2) {
                if (!berserkerDone && ModConfig.nonEmpty(cfg.berserkerMsgS4)) {
                    String msg = cfg.berserkerMsgS4.replace("(berserker)", berserkerName);
                    sendPc(msg);
                }
                inP3 = false;
            }
        }
    }

    private String fetchBerserkerName() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null) return "Berserker";

        for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
            Text displayName = entry.getDisplayName();
            if (displayName == null) continue;
            String line = displayName.getString();
            if (line.contains("[B]")) {
                return entry.getProfile().name();
            }
        }
        return "Berserker";
    }

    private boolean isBerserker(String playerName) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null) return false;

        Collection<PlayerListEntry> entries = mc.getNetworkHandler().getPlayerList();
        for (PlayerListEntry entry : entries) {
            Text displayName = entry.getDisplayName();
            if (displayName == null) continue;
            String line = displayName.getString();
            if (line.contains("[B]") && line.contains(playerName)) return true;
        }
        return false;
    }

    private void sendPc(String message) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.getNetworkHandler() != null)
            mc.getNetworkHandler().sendChatCommand("pc " + message);
    }
}
