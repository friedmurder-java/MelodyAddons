package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.*;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class BerserkerTracker {

    private static final Pattern VALID_NAME = Pattern.compile("^[A-Za-z0-9_]{3,16}$");

    private static final String P3_START = "Who dares trespass into my domain";
    private static final String SCAN_TRIGGER = "Starting in 1 second.";

    private boolean inP3 = false;
    private int scanTimer = -1;

    private final List<String> berserkerNames = new ArrayList<>();
    private String lastName = null;

    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    public void tick() {
        if (scanTimer > 0) {
            scanTimer--;
        } else if (scanTimer == 0) {
            boolean found = scan();
            scanTimer = found ? -1 : 20;
        }
    }

    public void onChatMessage(String raw) {
        if (!ModConfig.get().berserkerTracker) return;

        if (raw.contains(SCAN_TRIGGER)) {
            scanTimer = 60;
            return;
        }

        if (raw.contains(P3_START)) {
            inP3 = true;
            berserkerNames.clear();
            lastName = null;
        }
    }

    private boolean scan() {
        berserkerNames.clear();

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return false;

        Scoreboard scoreboard = mc.world.getScoreboard();

        // ======================
        // SCOREBOARD SCAN
        // ======================
        for (Team team : scoreboard.getTeams()) {
            String text = (team.getPrefix().getString() + team.getSuffix().getString()).toLowerCase();

            for (String player : team.getPlayerList()) {
                String clean = player.replaceAll("§[0-9a-fk-orx]", "").trim();

                if (!VALID_NAME.matcher(clean).matches()) continue;
                if (clean.contains("!") || clean.contains("-")) continue;

                if (!berserkerNames.contains(clean)) {
                    berserkerNames.add(clean);
                }
            }
        }

        // ======================
        // TABLIST FALLBACK
        // ======================
        if (berserkerNames.isEmpty() && mc.getNetworkHandler() != null) {
            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {

                String name = entry.getProfile().name();

                if (VALID_NAME.matcher(name).matches()) {
                    if (!berserkerNames.contains(name)) {
                        berserkerNames.add(name);
                    }
                }
            }
        }

        // ======================
        // OUTPUT
        // ======================
        if (!berserkerNames.isEmpty() && mc.player != null) {
            String msg = String.join(", ", berserkerNames);

            mc.player.sendMessage(
                    Text.literal("§d[MelodyAddons] §fBerserker: §b" + msg),
                    false
            );

            return true;
        }

        return false;
    }
}