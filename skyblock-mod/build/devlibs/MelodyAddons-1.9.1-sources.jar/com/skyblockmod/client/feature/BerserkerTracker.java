package com.skyblockmod.client.feature;

import com.skyblockmod.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.*;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BerserkerTracker {

    private static final Pattern DEVICE_DONE = Pattern.compile("(.+) completed a device! \\(\\d+/7\\)", Pattern.CASE_INSENSITIVE);
    private static final Pattern SEVEN_OF_SEVEN = Pattern.compile("\\(7/7\\)");
    private static final String P3_START = "Who dares trespass into my domain";
    private static final String SCAN_TRIGGER = "Starting in 1 second.";

    private boolean inP3 = false, inS1 = false, berserkerDone = false, notDoneSent = false, doneMsgSent = false;
    private int sevenOfSevenCount = 0;
    private int scanTimer = -1, retryCount = 0;

    private final List<String> berserkerNames = new ArrayList<>();
    private String lastActiveBerserker = null;

    private static final BerserkerTracker INSTANCE = new BerserkerTracker();
    public static BerserkerTracker get() { return INSTANCE; }
    private BerserkerTracker() {}

    public void tick() {
        if (scanTimer > 0) scanTimer--;
        else if (scanTimer == 0) {
            boolean found = performGlobalScan();
            if (!found && retryCount < 10) {
                retryCount++;
                scanTimer = 40;
            } else {
                scanTimer = -1;
                retryCount = 0;
            }
        }
    }

    public void onChatMessage(String raw) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.berserkerTracker) return;

        if (raw.contains(SCAN_TRIGGER)) {
            scanTimer = 20;
            retryCount = 0;
            return;
        }

        if (raw.contains(P3_START)) {
            inP3 = true; inS1 = true; berserkerDone = false; notDoneSent = false; doneMsgSent = false;
            sevenOfSevenCount = 0; lastActiveBerserker = null;
            return;
        }

        if (!inP3) return;

        Matcher mDevice = DEVICE_DONE.matcher(raw);
        if (mDevice.find()) {
            String playerName = mDevice.group(1).trim();
            if (isKnownBerserker(playerName) || (berserkerNames.isEmpty() && isPlayerSelf(playerName))) {
                berserkerDone = true;
                lastActiveBerserker = playerName;
                if (!doneMsgSent && ModConfig.nonEmpty(cfg.berserkerMsgStart)) {
                    sendFormattedPc(cfg.berserkerMsgStart, playerName);
                    doneMsgSent = true;
                }
            }
        }

        if (SEVEN_OF_SEVEN.matcher(raw).find()) {
            sevenOfSevenCount++;
            if (sevenOfSevenCount == 1) {
                inS1 = false;
                if (!berserkerDone && !notDoneSent && ModConfig.nonEmpty(cfg.berserkerMsgNotDone)) {
                    sendFormattedPc(cfg.berserkerMsgNotDone, getBestBerserkerName());
                    notDoneSent = true;
                }
            } else if (sevenOfSevenCount == 2) {
                if (!berserkerDone && ModConfig.nonEmpty(cfg.berserkerMsgS4)) {
                    sendFormattedPc(cfg.berserkerMsgS4, getBestBerserkerName());
                }
                inP3 = false;
            }
        }
    }

    private boolean performGlobalScan() {
        berserkerNames.clear();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return false;

        Scoreboard scoreboard = mc.world.getScoreboard();
        ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);

        // 1. Sidebar Scan
        if (objective != null) {
            for (ScoreboardEntry entry : scoreboard.getScoreboardEntries(objective)) {
                String line = entry.name().getString().replaceAll("§[0-9a-fk-orx]", "");
                // Looking for "(Berserk" instead of "[B]"
                if (line.contains("(Berserk")) {
                    String name = extractNameFromFormat(line);
                    if (name != null && !berserkerNames.contains(name)) berserkerNames.add(name);
                }
            }
        }

        // 2. Tab List Scan
        if (berserkerNames.isEmpty() && mc.getNetworkHandler() != null) {
            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
                Text dn = entry.getDisplayName();
                if (dn != null && dn.getString().contains("(Berserk")) {
                    String name = entry.getProfile().name();
                    if (!berserkerNames.contains(name)) berserkerNames.add(name);
                }
            }
        }

        if (!berserkerNames.isEmpty()) {
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal("§d[MelodyAddons] §fBerserker: §b" + String.join(", ", berserkerNames)), false);
            }
            return true;
        }
        return false;
    }

    private String extractNameFromFormat(String line) {
        // Line format: "[123] Itayver2013 (Berserk XXXV)"
        // We want the part before "(Berserk"
        if (line.contains("(Berserk")) {
            String beforeClass = line.split("\\(Berserk")[0].trim();
            // Split by space and take the last part (this ignores level numbers like [123])
            String[] parts = beforeClass.split("\\s+");
            if (parts.length > 0) {
                String name = parts[parts.length - 1];
                if (name.equalsIgnoreCase("You") && MinecraftClient.getInstance().player != null) {
                    return MinecraftClient.getInstance().player.getName().getString();
                }
                return name;
            }
        }
        return null;
    }

    private boolean isKnownBerserker(String playerName) {
        for (String name : berserkerNames) if (name.equalsIgnoreCase(playerName)) return true;
        return false;
    }

    private boolean isPlayerSelf(String playerName) {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player != null && mc.player.getName().getString().equalsIgnoreCase(playerName);
    }

    private String getBestBerserkerName() {
        if (lastActiveBerserker != null) return lastActiveBerserker;
        return !berserkerNames.isEmpty() ? berserkerNames.get(0) : "Berserker";
    }

    private void sendFormattedPc(String message, String name) {
        String finalMsg = message.replace("(berserker)", name);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.getNetworkHandler() != null)
            mc.getNetworkHandler().sendChatCommand("pc " + finalMsg);
    }
}
